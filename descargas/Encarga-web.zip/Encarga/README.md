# Encarga · Beta web para una tienda

Web instalable en el teléfono para organizar los productos que los clientes encargan a **una tienda con varios administradores** para comprar en Temu. Interfaz en español, sin cuentas de clientes ni códigos de grupo.

Este es el proyecto principal actual. El prototipo Android inicial queda como antecedente en `app/`, con documentación en `docs/ANDROID.md`; la web no depende de Firebase ni de Android Studio.

## Cómo probar

La vista previa se ejecuta en el **puerto 3000**.

1. **Administrador → Crear cuenta:** configura teléfono y una contraseña propia de al menos 8 caracteres. Solo la primera cuenta se crea desde esta pantalla. Los demás accesos se crean en **Administrador → Administradores → Agregar administrador**.
2. **Clientes / Hacer un encargo:** el formulario muestra automáticamente el rol Administrador, sin identidad personal. El cliente completa nombre, referencia de entrega opcional, producto, enlace HTTPS de Temu, imagen, precio en USD y cantidad. Talla/color/notas están en un desplegable opcional.
3. Pulsa **Enviar mi encargo**. No se pide un código ni un inicio de sesión al cliente. El servidor elige la destinataria, no el formulario.
4. El Administrador entra con su teléfono y contraseña para ver pedidos, imágenes, enlaces, totales, búsqueda, estados y exportación CSV. En la tarjeta de la tienda puede **Cerrar encargos** y volver a **Abrir encargos** cuando quiera.

**Explorar demo** muestra cuatro encargos ficticios sin crear una cuenta ni guardar cambios. No habilita encargos reales. La barra inferior cambia entre Inicio, Clientes y Administrador.

El Administrador puede pulsar **Compartir app** para copiar `/?pedido=1`, que abre directamente el formulario. Compartir este enlace es opcional: desde el inicio también se puede pedir. El enlace no incluye identificadores de profesora ni códigos.

La primera cuenta debe crearla el Administrador **antes de difundir la app**. Sin una destinataria configurada, el formulario informa que aún no se reciben encargos y no permite enviarlos. El registro se cierra en el servidor cuando existe una cuenta: no basta con ocultar el botón.

## Abrir y cerrar encargos

- El Administrador destinataria usa **Cerrar encargos / Abrir encargos** en su panel. Las instalaciones nuevas y antiguas conservan el comportamiento inicial abierto, hasta que ella lo cierre.
- El estado se guarda por tienda en SQLite y persiste al salir o reiniciar el servidor.
- Cerrar no elimina los pedidos existentes ni impide consultarlos, exportarlos o actualizar sus estados.
- El cliente ve «Encargos cerrados por ahora» y no puede enviar. El formulario conserva lo escrito mientras permanezca en esa pantalla (no al recargar o salir).
- El aviso se actualiza al abrir la pantalla, volver a enfocar la ventana, cada 15 segundos o con **Comprobar disponibilidad**. El Administrador también consulta el estado cada 15 segundos.
- El servidor verifica el cierre en cada envío, aunque el cliente tenga una pantalla antigua o intente enviar directamente al API. Si se cerró mientras completaba el formulario, conserva sus datos y muestra el aviso.
- Cualquier administrador activo de la tienda puede cambiar la disponibilidad para todos.
- La demo permite probar el botón sin afectar los encargos reales.

## Interfaz y carga

- Guía visual del usuario en `docs/DESIGN.md`: blanco/negro/gris, Geist local, tarjetas de 24 px y controles redondeados. Rojo reservado para errores.
- Se conservan las cuatro tarjetas de resumen del Administrador, la tarjeta de la tienda y la lista de pedidos.
- Inicio sencillo con dos accesos y navegación inferior; formulario sin paneles laterales ni selección de grupos.
- Animaciones al preparar la imagen, enviar el encargo y cargar el listado; confirmación animada solo después de guardar.
- Sin porcentajes ficticios ni esperas artificiales. En conexiones rápidas la animación puede ser breve.
- Se bloquean formulario y navegación durante el envío. Un error conserva los datos para reintentar.
- Se respeta «reducir movimiento» del sistema.

`web/src/style.css`: distribución responsive base. `theme.css`: tokens y adaptación visual. `app-layout.css`: pantallas, controles y animaciones de la vista tipo app.

## Desarrollo

Requiere **Node.js 22.13 o superior**, con `node:sqlite` (puede imprimir un aviso experimental).

```sh
npm ci
npm run dev
```

En un equipo local abre `http://localhost:3000`. El servidor escucha en `0.0.0.0`, acepta el host de vista previa y el cliente usa rutas relativas para el API.

```sh
npm run build
npm start
```

Producción sirve `dist/`. Variables opcionales: `PORT`, `DB_PATH` y `RECEIVING_TEACHER_PHONE` (ver migración).

## Datos y seguridad de la beta

React + Vite, API Express y SQLite en `data/beta.sqlite`. Las imágenes JPG, PNG o WebP de hasta 2 MB se guardan en SQLite. Los dispositivos conectados al mismo servidor comparten los encargos, no se usa localStorage como base de datos.

- Contraseñas con scrypt y sal aleatoria; cookies HttpOnly, SameSite y Secure bajo HTTPS. Sesiones de 7 días, revocadas al salir.
- El cliente solo puede enviar; no puede listar pedidos. El servidor selecciona el Administrador receptora incluso si el cliente intenta enviar otro identificador o un código antiguo.
- `/api/school` informa si el formulario está habilitado y el rol fijo Administrador. No expone teléfono, contraseña, código ni lista de pedidos.
- Las rutas del panel requieren una sesión activa y pertenencia a la tienda; todos sus administradores comparten pedidos. Las preferencias de notificaciones siguen siendo privadas por cuenta.
- Validaciones de importes en centavos, cantidades, enlaces `temu.com`/subdominios, imágenes y estados; consultas parametrizadas, rechazo de escrituras de origen ajeno y límite básico de solicitudes.
- Los datos, dependencias, capturas y compilados están excluidos de Git.

**La vista previa y sus datos son temporales.** No uses información sensible ni contraseñas habituales. La base ignorada no forma parte de las instantáneas del código. Para uso real hacen falta alojamiento estable con HTTPS, almacenamiento persistente, backups, protección contra abuso, recuperación de cuentas y políticas de privacidad/consentimiento (especialmente para menores).

### Migración desde la beta con códigos

No se borran cuentas ni pedidos existentes. La columna interna `teachers.code` se conserva únicamente para compatibilidad del esquema; ya no se muestra, devuelve ni utiliza para recibir encargos.

- Si ya había **un Administrador**, se selecciona automáticamente y conserva su teléfono, contraseña e historial.
- Si existían varias cuentas y aún no se había fijado una receptora, el sistema **no elige una al azar**: bloquea los nuevos envíos. El responsable del servidor debe configurar `RECEIVING_TEACHER_PHONE` con el teléfono del Administrador existente y reiniciar.
- Si se especifica esa variable, su teléfono debe corresponder a una cuenta existente (o a la primera cuenta que se cree en una instalación vacía). Una configuración inválida no redirige los pedidos a otra persona.
- Las cuentas antiguas ajenas a la tienda no reciben permisos automáticamente: conservan sus datos en la base, pero no pueden iniciar sesión en la tienda. No se mezclan pedidos históricos de cuentas distintas.
- Los antiguos enlaces `?grupo=...` aún abren el formulario, pero el valor se ignora: todos los envíos nuevos van a la destinataria configurada.

No compartas teléfonos reales ni credenciales por chat para configurar el servidor.

## Instalar en el teléfono

PWA con manifiesto, iconos y pantalla de falta de conexión. No es un proyecto MIT App Inventor ni un archivo `.aia`.

- Android/Chrome: botón Instalar o menú → Instalar / Añadir a pantalla de inicio.
- iPhone/Safari: Compartir → Añadir a pantalla de inicio.
- Necesita HTTPS (o localhost en desarrollo). La vista integrada puede impedir el aviso; abre el enlace en otra pestaña.

Necesita internet para consultar o enviar. No guarda pedidos privados en caché ni simula éxito sin respuesta del servidor. La instalación en un teléfono real queda pendiente de verificar.

## Pruebas

```sh
npm test
npm run build
npx playwright install --with-deps chromium
npm run test:browser
```

36 pruebas automatizadas de API/notificaciones/equipo/operación (18 de la app, 7 de avisos, 5 del equipo y 6 de pagos/seguridad/respaldos): configuración inicial, registro único, hashes, login/logout, validaciones, creación sin código, destinataria impuesta por servidor, estados, aislamiento de cuentas antiguas, apertura/cierre y bloqueo de nuevos pedidos, persistencia del cierre, migración de una/varias cuentas y protección de origen.

Playwright usa una base en memoria y no agrega cuentas a la vista previa. Comprueba demo, cuatro tarjetas preservadas, registro, formulario sin código, cierre/apertura en otra pantalla de cliente, conservación del borrador y errores al cambiar la disponibilidad, imagen, error y reintento, animación/reducción de movimiento, total 2 × $8.50 = $17, aparición en el panel y tamaños de escritorio/móvil. Capturas en `.arena/` (ignorada). Puede usarse `CHROMIUM_EXECUTABLE_PATH` si ya existe Chromium.

## Límites

Registro manual: sin compras automáticas, importación desde Temu, transportistas, cobros ni notificaciones push. El estado y el precio son manuales. Enviar no confirma la compra ni un precio definitivo.

Sin verificación de teléfono, recuperación pública automática, cuentas de clientes ni edición posterior del encargo por el cliente. La recuperación de acceso la realiza el operador autorizado del servidor. El cliente debe contactar al Administrador con la referencia. Sin eliminación de cuenta/registros en la interfaz ni edición de productos/precios en el panel. Actualización del panel cada 30 segundos o manual.

La versión actual admite varios administradores para una tienda; no ofrece un catálogo público de tiendas ni selección de administradores para los clientes. Antes de venderla o publicarla, completar el checklist de privacidad, despliegue, respaldo externo y piloto de docs/OPERACION.md; validar capacidad y accesibilidad en el entorno de destino.

Aplicación independiente, no afiliada a Temu.

## Avisos por correo, SMS y WhatsApp

En el panel del Administrador, abre **Avisos de nuevos pedidos**. Introduce tus contactos, activa los canales deseados y confirma el consentimiento. Los teléfonos deben usar formato internacional, por ejemplo `+50371234567`. No se infiere el código de país ni se usa automáticamente el teléfono de inicio de sesión.

Los canales están desactivados inicialmente. Cada pedido confirmado genera un aviso por canal activado **para cada administrador activo**; no se avisa por intentos inválidos ni pedidos rechazados por cierre. No se agregan avisos retroactivos para pedidos anteriores a la activación.

### Configurar los servicios reales

`.env.example` documenta las variables; **no contiene claves reales**. Configúralas en el alojamiento del servidor (no en React ni en el repositorio). El proceso no carga archivos `.env` automáticamente: puedes usar la configuración del alojamiento o `node --env-file=.env web/server.js` en un entorno propio compatible.

**Correo / Resend:**
- `RESEND_API_KEY`: clave de API del proveedor.
- `NOTIFY_EMAIL_FROM`: remitente autorizado en un dominio verificado, por ejemplo `Encarga <pedidos@tu-dominio.com>`.
- El destinatario se guarda en las preferencias privadas del Administrador.

**SMS / Twilio:**
- `TWILIO_ACCOUNT_SID` y `TWILIO_AUTH_TOKEN`: credenciales del servidor.
- `TWILIO_SMS_FROM`: número autorizado para enviar SMS en formato internacional.
- Habilita los destinos geográficos necesarios; las cuentas de prueba pueden exigir destinatarios verificados.

**WhatsApp / Twilio:**
- Las mismas credenciales de Twilio.
- `TWILIO_WHATSAPP_FROM`: remitente WhatsApp Business autorizado, con `+` y código de país (admite también el prefijo `whatsapp:`).
- `TWILIO_WHATSAPP_CONTENT_SID`: SID de una plantilla de contenido aprobada para iniciar avisos por WhatsApp, sin depender de una conversación abierta de 24 horas.
- La plantilla debe tener **cuatro variables**: `1` nombre del cliente, `2` producto, `3` total decimal USD, `4` referencia. Ejemplo: «Nuevo encargo de {{1}}. Producto: {{2}}. Total USD {{3}}. Referencia {{4}}. Revisa Encarga.»
- Obtén el consentimiento del titular y cumple las condiciones de WhatsApp/Twilio. Las pruebas en sandbox tienen restricciones propias; no es suficiente usar un número personal como remitente.

Reinicia el servidor tras configurar variables. SMS/WhatsApp pueden cobrar por mensajes, segmentos y plantillas; revisa también límites, saldo y costos de correo. El indicador «Configurado en servidor» solo confirma que hay variables, **no valida la conexión ni garantiza entrega**.

### Cola, estados y fallos

- SQLite guarda el pedido y su cola de avisos en una transacción. El envío al proveedor se hace aparte, cada 5 segundos, en lotes de hasta 10; nunca se espera al proveedor para confirmar un pedido.
- Si faltan proveedores, los avisos quedan como **Falta conectar proveedor**. Se procesarán al conectar el servicio y reiniciar, incluidos los anteriores en cola: revisa los contactos y la cola antes de activar el servicio. Un canal sin configurar no bloquea los demás.
- Desactivar un canal o cambiar su destinatario cancela sus avisos todavía pendientes. No retira un aviso que ya se estaba enviando o fue aceptado.
- Un fallo de correo/SMS/WhatsApp no elimina el pedido y no impide intentar los otros canales. Los rechazos se registran sin exponer credenciales.
- **Aceptado por proveedor** significa que el API aceptó la solicitud, no que llegó al teléfono o al correo. No hay webhooks de confirmación de entrega en esta beta. Consulta el panel del proveedor para investigar fallos posteriores.
- HTTP 429 se reintenta hasta tres intentos totales, separados por al menos un minuto. Los rechazos restantes quedan como fallidos. Una desconexión, timeout o reinicio en pleno envío produce **Resultado sin confirmar**, sin reintento automático para no duplicar mensajes potencialmente cobrados. Resend utiliza además una clave de idempotencia.
- No hay botón de reenvío en esta beta. La cola y las preferencias requieren el mismo disco persistente que la base de pedidos. Mantén una sola instancia del proceso despachador por base SQLite; no está diseñado como cola distribuida.
- Los destinos y el contenido (nombre, producto, total y referencia, sin imagen) se guardan de forma privada en el servidor y se comparten con el proveedor elegido. Antes de uso real: verificar titularidad de contactos, privacidad/consentimiento de clientes, retención, límites de gasto y protección contra abuso de envíos públicos.

**Verificación:** las integraciones se probaron con respuestas simuladas, sin enviar mensajes ni consumir saldo. Este entorno de vista previa no tiene credenciales de los proveedores y restringe el acceso saliente a sus dominios; para verificar los tres envíos reales se necesita un despliegue con acceso a `api.resend.com` y `api.twilio.com` y los servicios configurados. No compartas claves ni tokens por chat.


## Identidad del Administrador

El rol visible ahora se llama **Administrador**, sin nombres personales en el inicio,
navegación, formulario, confirmaciones, demo o panel. El registro ya no solicita
nombre ni instituto; usa teléfono y contraseña para el acceso.

`/api/school` solo devuelve disponibilidad, estado de registro y el nombre fijo
«Administrador» si hay una cuenta configurada. No expone teléfono, correo,
instituto ni identificadores. Las respuestas autenticadas de registro/login/sesión
tampoco devuelven nombres originales ni el teléfono de acceso. Los datos históricos
permanecen en SQLite para no borrar cuentas, pero no se muestran en la interfaz.

Los contactos de notificaciones se consultan/gestionan únicamente tras iniciar
sesión; no aparecen en el apartado de clientes. Esto oculta la identidad ante
los clientes, **no garantiza anonimato frente al alojamiento o los proveedores**
que necesitan procesar los contactos para entregar los avisos.


## Varios administradores de una tienda

1. Un administrador con acceso entra a su panel y abre **Administradores**.
2. Introduce el teléfono del nuevo administrador y una contraseña inicial propia para ese acceso.
3. Pulsa **Crear acceso** y comparte esas credenciales con su titular por un medio privado.
4. El nuevo administrador inicia sesión normalmente y ve los mismos pedidos de la tienda. No necesita códigos ni crear una tienda distinta.

Todos los administradores activos tienen los mismos permisos: pedidos, estados, apertura/cierre y gestión de otros accesos. La lista privada muestra solo «Administrador», los últimos cuatro dígitos del teléfono y si es tu acceso. No se devuelven contraseñas ni teléfonos completos en esa lista. Los clientes no pueden consultar la lista de administradores.

**Desactivar** requiere confirmación, revoca las sesiones de ese acceso y cancela sus avisos pendientes. No borra pedidos ni cuenta. **Reactivar** permite volver a entrar con la contraseña existente; las sesiones antiguas no se recuperan. Nadie puede desactivar su propio acceso, evitando dejar la tienda sin administradores. Si una persona es retirada de la tienda, un compañero debe desactivar su acceso.

Los avisos por correo/SMS/WhatsApp se configuran **por administrador**; no se copian contactos ni preferencias al crear un acceso. Cada uno solo consulta y modifica sus propios contactos e historial de avisos. Varios administradores pueden recibir un aviso del mismo pedido por el mismo canal, con el costo correspondiente. Los servicios externos siguen pendientes de configuración real.

### Compatibilidad y límites del equipo

- Los nombres internos `teachers`, `student`, `section` y `/api/school` se conservan para compatibilidad, pero la interfaz habla de tienda/clientes y referencia de entrega opcional.
- La cuenta destinataria original pasa a ser el identificador estable de la tienda; no determina quién tiene que estar conectado. Desactivarla no elimina la tienda si quedan otros administradores activos.
- La migración crea membresías explícitas, conserva los pedidos de la tienda original y migra la cola para permitir un aviso por pedido, administrador y canal. No agrega automáticamente cuentas antiguas ajenas al equipo ni traslada sus pedidos.
- `RECEIVING_TEACHER_PHONE` se conserva para seleccionar una cuenta original en instalaciones antiguas ambiguas. No debe usarse para cambiar de tienda arbitrariamente después de crear el equipo.
- No hay jerarquía propietario/empleado, cambio de contraseñas ni recuperación desde la interfaz en esta beta. Para producción hacen falta roles ajustados al negocio, recuperación segura, invitaciones con contraseña elegida por el titular, auditoría y pruebas adicionales.
- La interfaz y API se comprobaron con dos sesiones distintas: crear acceso, entrar en la segunda cuenta y consultar el mismo pedido. Las pruebas de API verifican estado compartido, bloqueo de accesos, privacidad de preferencias, avisos por administrador y migración sin pérdida de datos.


### Tarjetas de configuración del panel

Los apartados **Administradores** y **Notificaciones** aparecen ahora como dos
cuadros independientes, con el mismo estilo de las tarjetas de resumen. Se
muestran lado a lado en computadora y apilados en teléfono.

- **Gestionar accesos** abre la ventana de administradores para crear, desactivar
  o reactivar accesos.
- **Configurar avisos** abre las preferencias privadas de correo, WhatsApp y SMS.
- Los formularios ya no se despliegan en medio del panel. Las ventanas admiten
  cierre con Escape, mantienen el foco dentro y lo devuelven al botón original.
- Las pruebas de navegador comprueban ambas tarjetas, su disposición responsive,
  la apertura/cierre de las ventanas y los flujos existentes de creación y avisos.

## Operación comercial: edición por tienda

- Abonos manuales en USD y saldo pendiente en el detalle del encargo.
- Anulación con motivo, sin borrar el movimiento ni simular reembolsos.
- Historial de pedidos y de cambios de la tienda; CSV con abonos/saldos.
- Cambio de contraseña y recuperación de acceso por el operador del servidor.
- Respaldo/restauración verificados, receta Docker/Compose y proxy HTTPS.

**Guía de instalación, cron de respaldos, recuperación y checklist de lanzamiento:**
[docs/OPERACION.md](docs/OPERACION.md).

Verificación actual: **36 pruebas automáticas**, además del recorrido de navegador.
La configuración Docker necesita validación en el servidor de destino. No se han
contratado dominio, alojamiento, mensajería ni almacenamiento externo. Sigue siendo
una instalación por tienda, no un servicio multiempresa con mensualidades.
