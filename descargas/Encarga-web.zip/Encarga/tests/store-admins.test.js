import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createApp} from '../web/server.js';
const product={student:'Cliente de prueba',section:'',product:'Mochila',price:1500,quantity:1,link:'https://www.temu.com/a',image:'data:image/png;base64,aGVsbG8=',note:''};
async function setup(){const created=createApp(':memory:',{receivingPhone:'',notificationOptions:{env:{}}});const server=created.app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
 async function req(route,method='GET',data,cookie){const response=await fetch(base+'/api'+route,{method,headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},body:data?JSON.stringify(data):undefined});return {status:response.status,data:await response.json(),cookie:response.headers.get('set-cookie')?.split(';')[0]};}
 const root=await req('/register','POST',{phone:'71111111',password:'root-testing-123'});
 return {...created,root,req,close:async()=>{await new Promise(r=>server.close(r));created.db.close();}};
}
test('solo un administrador autenticado crea accesos, sin cambiar su propia sesión ni revelar datos al público',async()=>{const f=await setup();try{
 assert.equal((await f.req('/admins')).status,401);assert.equal((await f.req('/admins','POST',{phone:'72222222',password:'second-testing-123'})).status,401);
 const created=await f.req('/admins','POST',{phone:'7222 2222',password:'second-testing-123'},f.root.cookie);assert.equal(created.status,201);assert.equal(created.cookie,undefined);assert.equal(created.data.password,undefined);
 assert.equal((await f.req('/admins','POST',{phone:'72222222',password:'second-testing-123'},f.root.cookie)).status,409);
 assert.equal((await f.req('/admins','POST',{phone:'73333333',password:'bad'},f.root.cookie)).status,400);
 const other=await f.req('/login','POST',{phone:'72222222',password:'second-testing-123'});assert.equal(other.status,200);
 const rootList=(await f.req('/admins','GET',undefined,f.root.cookie)).data;assert.equal(rootList.length,2);assert.equal(rootList.find(a=>a.id===created.data.id).self,false);
 assert.ok(rootList.every(a=>a.label==='Administrador'&&!('phone' in a)&&!('password' in a)));
 assert.equal((await f.req('/admins','GET',undefined,other.cookie)).data.find(a=>a.id===created.data.id).self,true);
 assert.equal((await f.req('/admins','POST',{phone:'73333333',password:'third-testing-123'},other.cookie)).status,201);
 const publicData=(await f.req('/school')).data;assert.equal(publicData.name,'Administrador');assert.equal(publicData.admins,undefined);assert.equal(publicData.phone,undefined);
}finally{await f.close();}});
test('los administradores comparten pedidos y apertura/cierre de la misma tienda',async()=>{const f=await setup();try{
 await f.req('/admins','POST',{phone:'72222222',password:'second-testing-123'},f.root.cookie);const other=await f.req('/login','POST',{phone:'72222222',password:'second-testing-123'});
 const order=await f.req('/orders','POST',product);assert.equal(order.status,201);
 assert.deepEqual((await f.req('/orders','GET',undefined,other.cookie)).data,(await f.req('/orders','GET',undefined,f.root.cookie)).data);
 assert.equal((await f.req('/orders/'+order.data.id,'PATCH',{status:'Comprado'},other.cookie)).status,200);
 assert.equal((await f.req('/orders','GET',undefined,f.root.cookie)).data[0].status,'Comprado');
 assert.equal((await f.req('/school','PATCH',{ordersOpen:false},other.cookie)).status,200);assert.equal((await f.req('/me','GET',undefined,f.root.cookie)).data.ordersOpen,false);
 assert.equal((await f.req('/orders','POST',product)).status,409);await f.req('/school','PATCH',{ordersOpen:true},f.root.cookie);assert.equal((await f.req('/me','GET',undefined,other.cookie)).data.ordersOpen,true);
}finally{await f.close();}});
test('preferencias privadas por administrador y avisos a cada acceso activo, incluso por el mismo canal',async()=>{const f=await setup();try{
 const created=await f.req('/admins','POST',{phone:'72222222',password:'second-testing-123'},f.root.cookie);const other=await f.req('/login','POST',{phone:'72222222',password:'second-testing-123'});
 const preferences=email=>({email:{enabled:true,destination:email},sms:{enabled:false,destination:''},whatsapp:{enabled:false,destination:''},consent:true});
 await f.req('/notifications','PUT',preferences('root@example.com'),f.root.cookie);await f.req('/notifications','PUT',preferences('second@example.com'),other.cookie);
 assert.equal((await f.req('/notifications','GET',undefined,other.cookie)).data.settings.email.destination,'second@example.com');
 assert.equal((await f.req('/notifications','GET',undefined,f.root.cookie)).data.settings.email.destination,'root@example.com');
 const order=await f.req('/orders','POST',product);assert.equal(order.status,201);assert.equal(f.db.prepare('SELECT count(*) n FROM notifications').get().n,2);
 assert.equal((await f.req('/notifications','GET',undefined,other.cookie)).data.history.length,1);
 assert.equal((await f.req('/admins/'+created.data.id,'PATCH',{active:false},f.root.cookie)).status,200);
 assert.equal(f.db.prepare("SELECT status FROM notifications WHERE teacher=?").get(created.data.id).status,'cancelled');
 await f.req('/orders','POST',product);assert.equal(f.db.prepare('SELECT count(*) n FROM notifications').get().n,3);
}finally{await f.close();}});
test('desactivar invalida sesiones, conserva los pedidos y exige iniciar sesión de nuevo tras reactivar',async()=>{const f=await setup();try{
 const created=await f.req('/admins','POST',{phone:'72222222',password:'second-testing-123'},f.root.cookie);const other=await f.req('/login','POST',{phone:'72222222',password:'second-testing-123'});
 const rootId=(await f.req('/admins','GET',undefined,f.root.cookie)).data.find(a=>a.self).id;
 assert.equal((await f.req('/admins/'+rootId,'PATCH',{active:false},f.root.cookie)).status,400);
 await f.req('/orders','POST',product);await f.req('/admins/'+created.data.id,'PATCH',{active:false},f.root.cookie);
 assert.equal((await f.req('/orders','GET',undefined,other.cookie)).status,401);assert.equal((await f.req('/login','POST',{phone:'72222222',password:'second-testing-123'})).status,403);
 assert.equal((await f.req('/orders','GET',undefined,f.root.cookie)).data.length,1);
 await f.req('/admins/'+created.data.id,'PATCH',{active:true},f.root.cookie);
 assert.equal((await f.req('/me','GET',undefined,other.cookie)).status,401);assert.equal((await f.req('/login','POST',{phone:'72222222',password:'second-testing-123'})).status,200);
 assert.equal((await f.req('/admins/not-in-store','PATCH',{active:false},f.root.cookie)).status,404);
}finally{await f.close();}});

test('la migración conserva avisos e historial y permite el mismo canal a varios administradores',async()=>{
 const {mkdtempSync,rmSync}=await import('node:fs');const {tmpdir}=await import('node:os');const path=await import('node:path');
 const directory=mkdtempSync(path.join(tmpdir(),'encarga-team-'));const filename=path.join(directory,'beta.sqlite');let created;
 try{
  created=createApp(filename,{receivingPhone:'',notificationOptions:{env:{}}});
  created.db.prepare('INSERT INTO teachers VALUES (?,?,?,?,?,?)').run('root','Nombre antiguo','Tienda','71111111','hash','code1');
  created.db.prepare("INSERT INTO app_settings VALUES ('receiving_teacher','root')").run();
  created.db.prepare('INSERT INTO teachers VALUES (?,?,?,?,?,?)').run('staff','Nombre privado','Tienda','72222222','hash','code2');
  created.db.prepare('INSERT INTO store_members VALUES (?,?,?)').run('staff','root',0);
  created.db.prepare('INSERT INTO orders (id,teacher,student,section,product,price,quantity,link,image,note,status,created) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').run('old-order','root','Cliente','','Producto',100,1,'https://www.temu.com','data:image/png;base64,aA==','','Pendiente','2026-01-01');
  const sql=created.db.prepare("SELECT sql FROM sqlite_master WHERE name='notifications'").get().sql.replace('UNIQUE(order_id, teacher, channel)','UNIQUE(order_id, channel)');
  created.db.exec('DROP TABLE notifications;'+sql);
  created.db.prepare('INSERT INTO notifications (id,teacher,order_id,channel,destination,payload,status,created) VALUES (?,?,?,?,?,?,?,?)').run('legacy-notice','root','old-order','email','old@example.com','{}','accepted','2026-01-01');
  created.db.close();created=createApp(filename,{receivingPhone:'',notificationOptions:{env:{}}});
  assert.equal(created.db.prepare('SELECT count(*) n FROM orders').get().n,1);
  assert.equal(created.db.prepare("SELECT status FROM notifications WHERE id='legacy-notice'").get().status,'accepted');
  assert.equal(created.db.prepare("SELECT active FROM store_members WHERE teacher='staff'").get().active,0);
  assert.equal(created.db.prepare("SELECT store_id FROM store_members WHERE teacher='root'").get().store_id,'root');
  created.db.prepare('INSERT INTO notifications (id,teacher,order_id,channel,destination,payload,status,created) VALUES (?,?,?,?,?,?,?,?)').run('new-notice','staff','old-order','email','staff@example.com','{}','cancelled','2026-01-01');
  assert.equal(created.db.prepare('SELECT count(*) n FROM notifications').get().n,2);
 }finally{created?.db.close();rmSync(directory,{recursive:true,force:true});}
});
