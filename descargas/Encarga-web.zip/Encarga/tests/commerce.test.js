import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createApp} from '../web/server.js';
import {snapshot} from '../scripts/storage.mjs';
import {mkdtempSync,rmSync,statSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const product={student:'Cliente',section:'',product:'Producto',price:1500,quantity:2,link:'https://temu.com/a',image:'data:image/png;base64,aA==',note:''};
async function setup(file=':memory:'){
 const created=createApp(file,{receivingPhone:'',notificationOptions:{env:{}}});const server=created.app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));
 async function req(route,method='GET',body,cookie){const r=await fetch('http://127.0.0.1:'+server.address().port+'/api'+route,{method,headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},body:body?JSON.stringify(body):undefined});return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
 const root=await req('/register','POST',{phone:'71111111',password:'test-password-123'});
 const order=(await req('/orders','POST',product)).data.id;
 const payment=(amount=1000,key='test-payment-key-123')=>({amount,method:'Efectivo',note:'Caja',requestKey:key});
 return {...created,root,order,payment,req,close:async()=>{await new Promise(r=>server.close(r));created.db.close();}};
}
test('abonos privados en centavos: saldo, idempotencia y protección contra exceso',async()=>{const f=await setup();try{
 const route='/orders/'+f.order+'/payments';
 assert.equal((await f.req('/orders/'+f.order+'/ledger')).status,401);
 assert.equal((await f.req(route,'POST',f.payment())).status,401);
 assert.equal((await f.req('/activity')).status,401);
 for(const amount of [-1,0,1.5,'100',null])assert.equal((await f.req(route,'POST',f.payment(amount),f.root.cookie)).status,400);
 assert.equal((await f.req(route,'POST',f.payment(4000),f.root.cookie)).status,409);
 const payment=await f.req(route,'POST',f.payment(),f.root.cookie);assert.equal(payment.status,201);
 assert.equal((await f.req(route,'POST',f.payment(),f.root.cookie)).data.id,payment.data.id);
 assert.equal((await f.req(route,'POST',f.payment(999),f.root.cookie)).status,409);
 let ledger=(await f.req('/orders/'+f.order+'/ledger','GET',undefined,f.root.cookie)).data;
 assert.equal(ledger.total,3000);assert.equal(ledger.paid,1000);assert.equal(ledger.balance,2000);assert.equal(ledger.payments.length,1);
 assert.equal((await f.req(route,'POST',f.payment(2000,'test-payment-key-456'),f.root.cookie)).status,201);
 assert.equal((await f.req(route,'POST',f.payment(1,'test-payment-key-789'),f.root.cookie)).status,409);
 assert.equal((await f.req('/orders','GET',undefined,f.root.cookie)).data[0].paid,3000);
 ledger=(await f.req('/orders/'+f.order+'/ledger','GET',undefined,f.root.cookie)).data;assert.equal(ledger.balance,0);
 assert.equal(ledger.history.filter(h=>h.action==='Abono registrado').length,2);
}finally{await f.close();}});
test('anulación conserva movimientos y cancelación nunca reembolsa sola',async()=>{const f=await setup();try{
 const route='/orders/'+f.order;const p=(await f.req(route+'/payments','POST',f.payment(),f.root.cookie)).data;
 await f.req(route,'PATCH',{status:'Cancelado'},f.root.cookie);
 assert.equal((await f.req(route+'/payments','POST',f.payment(100,'another-payment-key-123'),f.root.cookie)).status,409);
 assert.equal((await f.req(route+'/ledger','GET',undefined,f.root.cookie)).data.paid,1000);
 const reverse=route+'/payments/'+p.id+'/reverse';
 assert.equal((await f.req(reverse,'POST',{reason:''},f.root.cookie)).status,400);
 assert.equal((await f.req(reverse,'POST',{reason:'Devolución efectuada en caja'},f.root.cookie)).status,200);
 assert.equal((await f.req(reverse,'POST',{reason:'Segundo intento'},f.root.cookie)).status,200);
 const ledger=(await f.req(route+'/ledger','GET',undefined,f.root.cookie)).data;
 assert.equal(ledger.paid,0);assert.equal(ledger.payments.length,1);assert.ok(ledger.payments[0].reversed);assert.equal(ledger.payments[0].reversal_note,'Devolución efectuada en caja');
 assert.equal(ledger.history.filter(h=>h.action==='Abono anulado').length,1);
 assert.equal((await f.req(reverse,'DELETE',undefined,f.root.cookie)).status,404);
}finally{await f.close();}});
test('otros administradores comparten el libro sin acceso a pedidos ajenos ni secretos',async()=>{const f=await setup();try{
 await f.req('/admins','POST',{phone:'72222222',password:'second-password-123'},f.root.cookie);
 const other=await f.req('/login','POST',{phone:'72222222',password:'second-password-123'});
 assert.equal((await f.req('/orders/'+f.order+'/payments','POST',f.payment(),other.cookie)).status,201);
 const ledger=(await f.req('/orders/'+f.order+'/ledger','GET',undefined,f.root.cookie)).data;
 assert.equal(ledger.paid,1000);assert.equal(ledger.history[0].self,0);assert.equal(ledger.history[0].actor,undefined);
 f.db.prepare('INSERT INTO teachers VALUES (?,?,?,?,?,?)').run('foreign','Privado','Privado','73333333','hash','code');
 f.db.prepare('INSERT INTO orders SELECT ?,?,student,section,product,price,quantity,link,image,note,status,created FROM orders WHERE id=?').run('foreign-order','foreign',f.order);
 for(const route of ['/ledger','/payments'])assert.equal((await f.req('/orders/foreign-order'+route,route==='/ledger'?'GET':'POST',route==='/ledger'?undefined:f.payment(),other.cookie)).status,404);
 assert.equal((await f.req('/orders/'+f.order+'/payments/missing/reverse','POST',{reason:'x'},other.cookie)).status,404);
 await f.req('/admins/'+(await f.req('/admins','GET',undefined,f.root.cookie)).data.find(a=>!a.self).id,'PATCH',{active:false},f.root.cookie);
 assert.equal((await f.req('/orders/'+f.order+'/ledger','GET',undefined,other.cookie)).status,401);
 assert.equal((await f.req('/orders/'+f.order+'/ledger','GET',undefined,f.root.cookie)).data.paid,1000);
}finally{await f.close();}});
test('fallo del historial revierte abono y cambio de estado de forma atómica',async()=>{const f=await setup();try{
 f.db.exec("CREATE TRIGGER fail_audit BEFORE INSERT ON audit_events BEGIN SELECT RAISE(ABORT,'test unavailable'); END");
 assert.equal((await f.req('/orders/'+f.order+'/payments','POST',f.payment(),f.root.cookie)).status,400);
 assert.equal(f.db.prepare('SELECT COUNT(*) n FROM payments').get().n,0);
 assert.equal((await f.req('/orders/'+f.order,'PATCH',{status:'Comprado'},f.root.cookie)).status,400);
 assert.equal(f.db.prepare('SELECT status FROM orders WHERE id=?').get(f.order).status,'Pendiente');
}finally{await f.close();}});
test('cambiar contraseña verifica la actual, revoca sesiones y mantiene la sesión nueva',async()=>{const f=await setup();try{
 const second=await f.req('/login','POST',{phone:'71111111',password:'test-password-123'});
 assert.equal((await f.req('/account/password','POST',{currentPassword:'incorrect',password:'new-password-123'},f.root.cookie)).status,403);
 const result=await f.req('/account/password','POST',{currentPassword:'test-password-123',password:'new-password-123'},f.root.cookie);assert.equal(result.status,200);assert.ok(result.cookie);
 assert.equal((await f.req('/me','GET',undefined,second.cookie)).status,401);
 assert.equal((await f.req('/me','GET',undefined,f.root.cookie)).status,401);
 assert.equal((await f.req('/me','GET',undefined,result.cookie)).status,200);
 assert.equal((await f.req('/login','POST',{phone:'71111111',password:'test-password-123'})).status,401);
 assert.equal((await f.req('/login','POST',{phone:'71111111',password:'new-password-123'})).status,200);
 const activity=(await f.req('/activity','GET',undefined,result.cookie)).data;
 assert.ok(activity.some(h=>h.action==='Contraseña actualizada'));assert.ok(!JSON.stringify(activity).includes('password-123'));
}finally{await f.close();}});
test('respaldo y restauración verifican datos, imágenes, saldos; recuperación operativa revoca sesiones',async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'encarga-backup-'));let f,restored;
 try{
 const source=path.join(dir,'store.sqlite'),backup=path.join(dir,'backup.sqlite'),target=path.join(dir,'restored.sqlite');f=await setup(source);
 await f.req('/orders/'+f.order+'/payments','POST',f.payment(),f.root.cookie);
 snapshot(source,backup);assert.equal(statSync(backup).mode&0o777,0o600);assert.throws(()=>snapshot(source,backup),/existe/);
 snapshot(backup,target,{restore:true});restored=createApp(target,{receivingPhone:'',notificationOptions:{env:{}}});
 assert.equal(restored.db.prepare('SELECT image FROM orders').get().image,product.image);
 assert.equal(restored.db.prepare('SELECT amount FROM payments').get().amount,1000);
 assert.equal(restored.db.prepare('SELECT COUNT(*) n FROM sessions').get().n,0);
 assert.ok(restored.db.prepare('SELECT COUNT(*) n FROM audit_events').get().n>=2);
 restored.db.close();restored=null;
 const result=spawnSync(process.execPath,['scripts/reset-password.mjs'],{cwd:process.cwd(),env:{...process.env,DB_PATH:target,RECOVERY_PHONE:'71111111',NEW_PASSWORD:'recovered-password-123'},encoding:'utf8'});
 assert.equal(result.status,0,result.stderr);assert.ok(!result.stdout.includes('recovered-password'));
 const wrong=spawnSync(process.execPath,['scripts/reset-password.mjs'],{env:{...process.env,DB_PATH:target,RECOVERY_PHONE:'79999999',NEW_PASSWORD:'recovered-password-123'},encoding:'utf8'});assert.equal(wrong.status,1);
 restored=createApp(target,{receivingPhone:'',notificationOptions:{env:{}}});assert.equal(restored.db.prepare("SELECT COUNT(*) n FROM audit_events WHERE action='Acceso recuperado'").get().n,1);
 }finally{restored?.db.close();await f?.close();rmSync(dir,{recursive:true,force:true});}
});
