import {test, before, after} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createApp} from '../web/server.js';
let server,db,base,cookie,teacher,orderId;
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aB1sAAAAASUVORK5CYII=';
before(async()=>{const created=createApp(':memory:');db=created.db;server=created.app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));base='http://127.0.0.1:'+server.address().port;});
after(()=>{server.close();db.close();});
async function request(path,method='GET',body,session){const res=await fetch(base+'/api'+path,{method,headers:{'Content-Type':'application/json',...(session?{Cookie:session}:{})},body:body?JSON.stringify(body):undefined});return {status:res.status,data:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0]};}
const newTeacher={name:'María González',classroom:'Instituto de prueba',phone:'7123 4567',password:'una-clave-segura'};
const order=()=>({student:'Ana López',section:'2° A',product:'Audífonos',price:850,quantity:2,link:'https://www.temu.com/test.html',image,note:'Color blanco'});
test('no permite acceder al panel sin sesión',async()=>{assert.equal((await request('/orders')).status,401);});
test('sin profesora, informa que el formulario aún no recibe encargos',async()=>{const r=await request('/school');assert.deepEqual(r.data,{ready:false,ordersOpen:false,registrationOpen:true});assert.equal((await request('/orders','POST',order())).status,503);});
test('registra profesora y almacena contraseña con hash',async()=>{const r=await request('/register','POST',newTeacher);assert.equal(r.status,201);assert.equal(r.data.code,undefined);teacher=r.data;cookie=r.cookie;assert.ok(cookie);const stored=db.prepare('SELECT password FROM teachers').get().password;assert.notEqual(stored,newTeacher.password);assert.ok(stored.includes(':'));});
test('recupera sesión y no expone contraseña',async()=>{const r=await request('/me','GET',undefined,cookie);assert.equal(r.status,200);assert.equal(r.data.name,'Administrador');assert.equal(r.data.phone,undefined);assert.equal(r.data.password,undefined);});
test('rechaza duplicados, contraseñas débiles y teléfonos inválidos',async()=>{assert.equal((await request('/register','POST',newTeacher)).status,409);assert.equal((await request('/register','POST',{...newTeacher,phone:'xx'})).status,400);assert.equal((await request('/register','POST',{...newTeacher,phone:'77777777',password:'123'})).status,400);});
test('el formulario detecta la profesora sin código ni datos privados',async()=>{const r=await request('/school');assert.equal(r.status,200);assert.equal(r.data.classroom,undefined);assert.equal(r.data.name,'Administrador');assert.equal(r.data.ready,true);assert.equal(r.data.registrationOpen,false);assert.equal(r.data.phone,undefined);assert.equal(r.data.code,undefined);assert.equal(r.data.password,undefined);assert.equal((await request('/classroom/INVALID')).status,404);});
test('envía encargo con imagen, precio entero y referencia',async()=>{const r=await request('/orders','POST',order());assert.equal(r.status,201);assert.match(r.data.id,/^[A-F0-9]{12}$/);orderId=r.data.id;const list=await request('/orders','GET',undefined,cookie);assert.equal(list.data.length,1);assert.equal(list.data[0].price*list.data[0].quantity,1700);assert.equal(list.data[0].image,image);});
test('rechaza importes negativos/fraccionarios, cantidades, enlaces externos y falta de imagen',async()=>{for(const patch of [{price:-1},{price:1.5},{quantity:0},{quantity:100},{image:''},{link:'javascript:alert(1)'},{link:'https://temu.com.evil.example/a'},{link:'http://temu.com/a'},{student:''}]){assert.equal((await request('/orders','POST',{...order(),...patch})).status,400,JSON.stringify(patch));}});
test('permite actualizar estado y rechaza valores desconocidos',async()=>{assert.equal((await request('/orders/'+orderId,'PATCH',{status:'Comprado'},cookie)).status,200);assert.equal((await request('/orders/'+orderId,'PATCH',{status:'Invalid'},cookie)).status,400);assert.equal((await request('/orders','GET',undefined,cookie)).data[0].status,'Comprado');});
test('no permite registrar otra profesora ni cambiar la destinataria desde el pedido',async()=>{
 const second=await request('/register','POST',{...newTeacher,name:'Otra profesora',phone:'77777777'});
 assert.equal(second.status,409);
 const receiverId=db.prepare("SELECT value FROM app_settings WHERE key='receiving_teacher'").get().value;
 const r=await request('/orders','POST',{...order(),code:'CUALQUIERA',teacher:'otra-cuenta',teacherId:'otra-cuenta'});
 assert.equal(r.status,201);
 assert.equal(db.prepare('SELECT teacher FROM orders WHERE id=?').get(r.data.id).teacher,receiverId);
});
test('una cuenta antigua distinta no ve ni modifica los encargos de la profesora',async()=>{
 const hash=db.prepare('SELECT password FROM teachers LIMIT 1').get().password;
 db.prepare('INSERT INTO teachers VALUES (?,?,?,?,?,?)').run('legacy','Otra profesora','Antiguo grupo','77777777',hash,'ANTIGUO');
 const second=await request('/login','POST',{phone:'77777777',password:newTeacher.password});
 assert.equal(second.status,403);
 assert.equal(second.cookie,undefined);
 assert.equal((await request('/admins','GET',undefined)).status,401);
});
test('solo la profesora abre/cierra encargos y cerrar no borra el historial',async()=>{
 assert.equal((await request('/school','PATCH',{ordersOpen:false})).status,401);
 for(const value of ['false',0,null]) assert.equal((await request('/school','PATCH',{ordersOpen:value},cookie)).status,400);
 const beforeCount=db.prepare('SELECT count(*) n FROM orders').get().n;
 assert.equal((await request('/school','PATCH',{ordersOpen:false},cookie)).status,200);
 const school=await request('/school');assert.equal(school.data.ready,true);assert.equal(school.data.ordersOpen,false);
 assert.equal((await request('/me','GET',undefined,cookie)).data.ordersOpen,false);
 const blocked=await request('/orders','POST',{...order(),ordersOpen:true});assert.equal(blocked.status,409);assert.equal(blocked.data.code,'ORDERS_CLOSED');
 assert.equal(db.prepare('SELECT count(*) n FROM orders').get().n,beforeCount);
 assert.equal((await request('/orders','GET',undefined,cookie)).data.length,beforeCount);
 assert.equal((await request('/school','PATCH',{ordersOpen:true},cookie)).status,200);
 assert.equal((await request('/school')).data.ordersOpen,true);
 assert.equal((await request('/orders','POST',order())).status,201);
});
test('login por teléfono normalizado y cierre de sesión invalidan la cookie',async()=>{assert.equal((await request('/login','POST',{phone:'71234567',password:'incorrecta'})).status,401);const login=await request('/login','POST',{phone:'7123-4567',password:newTeacher.password});assert.equal(login.status,200);assert.equal((await request('/logout','POST',{},login.cookie)).status,200);assert.equal((await request('/me','GET',undefined,login.cookie)).status,401);});
test('bloquea solicitudes de escritura de otro origen',async()=>{const r=await fetch(base+'/api/login',{method:'POST',headers:{Origin:'https://otra-web.example','Content-Type':'application/json'},body:JSON.stringify({phone:newTeacher.phone,password:newTeacher.password})});assert.equal(r.status,403);});

// Migration safety: never pick a random teacher when an older beta had several.
test('varias cuentas antiguas requieren configurar la destinataria sin borrar pedidos',async()=>{
 const directory=mkdtempSync(path.join(tmpdir(),'encarga-migration-'));
 const filename=path.join(directory,'beta.sqlite');
 let current;
 let listener;
 try {
  current=createApp(filename,{receivingPhone:''});
  for(const [id,phone] of [['a','71111111'],['b','72222222']]) current.db.prepare('INSERT INTO teachers VALUES (?,?,?,?,?,?)').run(id,'Profe '+id,'Instituto',phone,'hash-antiguo',id);
  current.db.close();
  current=createApp(filename,{receivingPhone:''});
  listener=current.app.listen(0,'127.0.0.1');await new Promise(r=>listener.once('listening',r));
  let url='http://127.0.0.1:'+listener.address().port;
  assert.equal((await (await fetch(url+'/api/school')).json()).ready,false);
  assert.equal((await fetch(url+'/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(order())})).status,503);
  await new Promise(r=>listener.close(r));listener=null;current.db.close();
  current=createApp(filename,{receivingPhone:'7222 2222'});
  listener=current.app.listen(0,'127.0.0.1');await new Promise(r=>listener.once('listening',r));url='http://127.0.0.1:'+listener.address().port;
  assert.equal((await (await fetch(url+'/api/school')).json()).name,'Administrador');
  const res=await fetch(url+'/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(order())});
  assert.equal(res.status,201);const {id}=await res.json();
  assert.equal(current.db.prepare('SELECT teacher FROM orders WHERE id=?').get(id).teacher,'b');
  assert.equal(current.db.prepare('SELECT count(*) n FROM teachers').get().n,2);
 } finally {if(listener)await new Promise(r=>listener.close(r));current?.db.close();rmSync(directory,{recursive:true,force:true});}
});
test('migra una sola profesora antigua automáticamente',async()=>{
 const directory=mkdtempSync(path.join(tmpdir(),'encarga-single-'));
 const filename=path.join(directory,'beta.sqlite');
 let current;
 try {
  current=createApp(filename,{receivingPhone:''});
  current.db.prepare('INSERT INTO teachers VALUES (?,?,?,?,?,?)').run('legacy-id','María','Instituto','71111111','hash','ANTIGUO');current.db.close();
  current=createApp(filename,{receivingPhone:''});
  assert.equal(current.db.prepare("SELECT value FROM app_settings WHERE key='receiving_teacher'").get().value,'legacy-id');
  assert.equal(current.db.prepare('SELECT count(*) n FROM teachers').get().n,1);
 }finally{current?.db.close();rmSync(directory,{recursive:true,force:true});}
});

test('el cierre persiste al reiniciar el servidor',async()=>{
 const directory=mkdtempSync(path.join(tmpdir(),'encarga-closed-'));const file=path.join(directory,'beta.sqlite');
 let current,listener;
 try {
  current=createApp(file,{receivingPhone:''});listener=current.app.listen(0,'127.0.0.1');await new Promise(r=>listener.once('listening',r));
  let url='http://127.0.0.1:'+listener.address().port;
  const created=await fetch(url+'/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(newTeacher)});
  const session=created.headers.get('set-cookie').split(';')[0];
  assert.equal((await fetch(url+'/api/school',{method:'PATCH',headers:{'Content-Type':'application/json',Cookie:session},body:JSON.stringify({ordersOpen:false})})).status,200);
  await new Promise(r=>listener.close(r));listener=null;current.db.close();
  current=createApp(file,{receivingPhone:''});listener=current.app.listen(0,'127.0.0.1');await new Promise(r=>listener.once('listening',r));url='http://127.0.0.1:'+listener.address().port;
  const school=await (await fetch(url+'/api/school')).json();assert.equal(school.ready,true);assert.equal(school.ordersOpen,false);
  assert.equal((await fetch(url+'/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(order())})).status,409);
 } finally {if(listener)await new Promise(r=>listener.close(r));current?.db.close();rmSync(directory,{recursive:true,force:true});}
});

test('la API oculta identidad y contactos de cuentas antiguas',async()=>{
 const id=db.prepare("SELECT value FROM app_settings WHERE key='receiving_teacher'").get().value;
 db.prepare('UPDATE teachers SET name=?,classroom=? WHERE id=?').run('Identidad privada','Instituto privado',id);
 const publicData=(await request('/school')).data;
 assert.equal(publicData.name,'Administrador');
 for(const key of ['phone','email','classroom','id','code','password','settings'])assert.equal(publicData[key],undefined);
 assert.ok(!JSON.stringify(publicData).includes('Identidad privada'));
 assert.ok(!JSON.stringify(publicData).includes('Instituto privado'));
 const own=(await request('/me','GET',undefined,cookie)).data;
 assert.equal(own.name,'Administrador');assert.equal(own.phone,undefined);
 assert.ok(!JSON.stringify(own).includes('Identidad privada'));
 assert.equal((await request('/notifications','GET',undefined)).status,401);
});
