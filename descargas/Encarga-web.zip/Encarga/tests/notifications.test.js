import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createApp} from '../web/server.js';
const contact={email:{enabled:true,destination:'teacher@example.com'},sms:{enabled:true,destination:'+50371234567'},whatsapp:{enabled:true,destination:'+50371234567'},consent:true};
const order={student:'Ana',section:'2 A',product:'Mochila',price:850,quantity:2,link:'https://www.temu.com/a',image:'data:image/png;base64,aGVsbG8=',note:''};
const env={RESEND_API_KEY:'test-key',NOTIFY_EMAIL_FROM:'Test <app@example.com>',TWILIO_ACCOUNT_SID:'ACtest',TWILIO_AUTH_TOKEN:'test-secret',TWILIO_SMS_FROM:'+15005550006',TWILIO_WHATSAPP_FROM:'+15005550006',TWILIO_WHATSAPP_CONTENT_SID:'HXtest'};
async function fixture(options={}){
 const {app,db,notifications}=createApp(':memory:',{receivingPhone:'',notificationOptions:{env:{},...options}});
 const server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
 let cookie;
 async function req(path,method='GET',body,authenticated=true){const r=await fetch(base+'/api'+path,{method,headers:{'Content-Type':'application/json',...(authenticated&&cookie?{Cookie:cookie}:{})},body:body?JSON.stringify(body):undefined});return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
 cookie=(await req('/register','POST',{name:'María',classroom:'Instituto',phone:'71234567',password:'testing-1234'})).cookie;
 return {db,notifications,req,close:async()=>{await new Promise(r=>server.close(r));db.close();}};
}
test('preferencias privadas, formatos y consentimiento antes de activar',async()=>{const f=await fixture();try{
 assert.equal((await f.req('/notifications','GET',undefined,false)).status,401);
 assert.equal((await f.req('/notifications','PUT',contact,false)).status,401);
 for(const patch of [{consent:false},{sms:{enabled:true,destination:'71234567'}},{email:{enabled:true,destination:'invalid'}}])assert.equal((await f.req('/notifications','PUT',{...contact,...patch})).status,400);
 assert.equal((await f.req('/notifications','PUT',contact)).status,200);
 const data=(await f.req('/notifications')).data;assert.equal(data.settings.email.destination,'teacher@example.com');assert.deepEqual(data.providers,{email:false,sms:false,whatsapp:false});
 const school=(await f.req('/school','GET',undefined,false)).data;assert.equal(school.email,undefined);assert.equal(school.settings,undefined);
}finally{await f.close();}});
test('pedido guardado crea tres avisos; sin proveedores no finge envíos',async()=>{let calls=0;const f=await fixture({sendFetch:async()=>{calls++;throw Error('must not send');}});try{
 await f.req('/notifications','PUT',contact);const created=await f.req('/orders','POST',order,false);assert.equal(created.status,201);
 await f.notifications.dispatch();const list=(await f.req('/notifications')).data.history;assert.equal(list.length,3);assert.ok(list.every(n=>n.status==='unconfigured'));assert.equal(calls,0);
 assert.equal((await f.req('/orders')).data.length,1);
 await f.req('/school','PATCH',{ordersOpen:false});assert.equal((await f.req('/orders','POST',order,false)).status,409);assert.equal(f.db.prepare('SELECT count(*) n FROM notifications').get().n,3);
}finally{await f.close();}});
test('proveedores reciben correo, SMS y plantilla WhatsApp, una vez por aviso',async()=>{const calls=[];const f=await fixture({env,sendFetch:async(url,options)=>{calls.push({url,options});return new Response(JSON.stringify(url.includes('resend')?{id:'email-id'}:{sid:'SMtest'}),{status:200});}});try{
 await f.req('/notifications','PUT',contact);await f.req('/orders','POST',order,false);await Promise.all([f.notifications.dispatch(),f.notifications.dispatch()]);await f.notifications.dispatch();assert.equal(calls.length,3);
 const email=calls.find(c=>c.url.includes('resend'));assert.ok(email.options.headers['Idempotency-Key']);assert.match(JSON.parse(email.options.body).text,/17.00/);
 const whatsapp=calls.find(c=>c.options.body instanceof URLSearchParams&&c.options.body.has('ContentSid'));assert.equal(whatsapp.options.body.get('To'),'whatsapp:+50371234567');assert.equal(whatsapp.options.body.get('ContentSid'),'HXtest');assert.equal(JSON.parse(whatsapp.options.body.get('ContentVariables'))['1'],'Ana');
 const sms=calls.find(c=>c.options.body instanceof URLSearchParams&&c.options.body.has('Body'));assert.match(sms.options.body.get('Body'),/Mochila/);
 assert.ok((await f.req('/notifications')).data.history.every(n=>n.status==='accepted'));
}finally{await f.close();}});
test('un fallo de canal no pierde el pedido ni impide los demás; errores no filtran secretos',async()=>{const f=await fixture({env,sendFetch:async url=>{if(url.includes('resend'))throw Error('test-secret');return new Response(JSON.stringify({sid:'SMtest'}));}});try{
 await f.req('/notifications','PUT',contact);assert.equal((await f.req('/orders','POST',order,false)).status,201);await f.notifications.dispatch();
 const history=(await f.req('/notifications')).data.history;assert.equal(history.filter(n=>n.status==='accepted').length,2);assert.equal(history.find(n=>n.channel==='email').status,'unknown');assert.ok(!JSON.stringify(history).includes('test-secret'));assert.equal((await f.req('/orders')).data.length,1);
}finally{await f.close();}});
test('desactivar o cambiar el contacto cancela avisos pendientes; no hay avisos retroactivos',async()=>{const f=await fixture();try{
 await f.req('/orders','POST',order,false);assert.equal(f.notifications.history(f.db.prepare('SELECT id FROM teachers').get().id).length,0);
 await f.req('/notifications','PUT',contact);await f.req('/orders','POST',order,false);
 await f.req('/notifications','PUT',{...contact,email:{enabled:true,destination:'new@example.com'},sms:{enabled:false,destination:'+50371234567'}});
 const history=(await f.req('/notifications')).data.history;assert.equal(history.find(n=>n.channel==='email').status,'cancelled');assert.equal(history.find(n=>n.channel==='sms').status,'cancelled');
}finally{await f.close();}});
test('la cola es atómica con el pedido si falla la escritura de un aviso',async()=>{const f=await fixture();try{
 await f.req('/notifications','PUT',contact);f.db.exec("CREATE TRIGGER fail_notice BEFORE INSERT ON notifications BEGIN SELECT RAISE(ABORT,'outbox unavailable'); END;");
 assert.equal((await f.req('/orders','POST',order,false)).status,400);assert.equal(f.db.prepare('SELECT count(*) n FROM orders').get().n,0);assert.equal(f.db.prepare('SELECT count(*) n FROM notifications').get().n,0);
}finally{await f.close();}});
test('un proveedor ausente no bloquea otros canales ni las configuraciones posteriores',async()=>{
 const partialEnv={};let calls=0;const f=await fixture({env:partialEnv,sendFetch:async()=>{calls++;return new Response(JSON.stringify({sid:'SMtest'}));}});try{
 await f.req('/notifications','PUT',contact);
 for(let i=0;i<12;i++)await f.req('/orders','POST',order,false);
 partialEnv.TWILIO_ACCOUNT_SID=env.TWILIO_ACCOUNT_SID;partialEnv.TWILIO_AUTH_TOKEN=env.TWILIO_AUTH_TOKEN;partialEnv.TWILIO_SMS_FROM=env.TWILIO_SMS_FROM;
 await f.notifications.dispatch();await f.notifications.dispatch();assert.equal(calls,12);
 assert.equal(f.db.prepare("SELECT count(*) n FROM notifications WHERE channel='email' AND status='unconfigured'").get().n,12);
}finally{await f.close();}});
