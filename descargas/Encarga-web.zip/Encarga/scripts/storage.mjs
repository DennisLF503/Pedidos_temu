import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,existsSync,chmodSync,unlinkSync,openSync,closeSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

// VACUUM INTO creates a consistent SQLite snapshot, including inline images.
export function snapshot(source,destination,{restore=false}={}){
 const from=path.resolve(source),to=path.resolve(destination);
 if(!existsSync(from))throw new Error('La base de origen no existe.');
 if(existsSync(to)||from===to)throw new Error('El destino ya existe; nunca se sobrescriben datos.');
 mkdirSync(path.dirname(to),{recursive:true,mode:0o700});
 let db,owned=false;
 try{
  db=new DatabaseSync(from,{readOnly:true});
  if(db.prepare('PRAGMA integrity_check').get().integrity_check!=='ok'||db.prepare('PRAGMA foreign_key_check').all().length)throw new Error('El origen no supera la verificación de integridad.');
  if(!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='orders'").get())throw new Error('El origen no es una base de Encarga.');
  closeSync(openSync(to,'wx',0o600));owned=true;
  db.exec("VACUUM INTO '"+to.replaceAll("'","''")+"'");db.close();db=null;chmodSync(to,0o600);
  db=new DatabaseSync(to);db.exec('PRAGMA foreign_keys=ON');
  if(restore){
   db.exec('BEGIN IMMEDIATE');
   db.exec('DELETE FROM sessions');
   db.exec("UPDATE notifications SET status='cancelled',error=NULL WHERE status IN ('pending','unconfigured')");
   db.exec('COMMIT');
  }
  if(db.prepare('PRAGMA integrity_check').get().integrity_check!=='ok'||db.prepare('PRAGMA foreign_key_check').all().length)throw new Error('La copia no supera la verificación de integridad.');
 }catch(error){if(db){db.close();db=null;}if(owned&&existsSync(to))unlinkSync(to);throw error;}finally{db?.close();}
 return to;
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 process.umask(0o077);
 const [mode,source,destination]=process.argv.slice(2);
 if(!['backup','restore'].includes(mode)||!source||!destination){console.error('Uso: node scripts/storage.mjs backup|restore origen.sqlite destino-nuevo.sqlite');process.exitCode=1;}
 else try{console.log('Copia verificada: '+snapshot(source,destination,{restore:mode==='restore'}));}catch(e){console.error(e.message);process.exitCode=1;}
}
