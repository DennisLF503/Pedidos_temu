import {DatabaseSync} from 'node:sqlite';
import {existsSync} from 'node:fs';
import {scryptSync,randomBytes} from 'node:crypto';
// Operator-only recovery: no public reset tokens or new administrative access.
const file=process.env.DB_PATH||'data/beta.sqlite';
const phone=(process.env.RECOVERY_PHONE||'').replace(/[\s()+-]/g,'');
const password=process.env.NEW_PASSWORD;
delete process.env.NEW_PASSWORD;
let db;
try{
 if(!existsSync(file))throw new Error('La base no existe.');
 if(!/^\d{8,15}$/.test(phone)||typeof password!=='string'||password.length<8||password.length>128)throw new Error('Define RECOVERY_PHONE y NEW_PASSWORD (8–128 caracteres) mediante un entorno privado.');
 db=new DatabaseSync(file);db.exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000');
 const account=db.prepare('SELECT teachers.id,store_members.store_id FROM teachers JOIN store_members ON teachers.id=store_members.teacher WHERE teachers.phone=? AND store_members.active=1').get(phone);
 if(!account)throw new Error('No se encontró un administrador activo. No se ha creado ni reactivado ningún acceso.');
 const salt=randomBytes(16).toString('hex');
 db.exec('BEGIN IMMEDIATE');
 try{
  db.prepare('UPDATE teachers SET password=? WHERE id=?').run(salt+':'+scryptSync(password,salt,64).toString('hex'),account.id);
  db.prepare('DELETE FROM sessions WHERE teacher=?').run(account.id);
  db.prepare('INSERT INTO audit_events (store_id,actor,action,detail,created) VALUES (?,?,?,?,?)').run(account.store_id,account.id,'Acceso recuperado','Recuperación por el operador del servidor; sesiones cerradas',new Date().toISOString());
  db.exec('COMMIT');
 }catch(e){db.exec('ROLLBACK');throw e;}
 console.log('Contraseña actualizada y sesiones cerradas.');
}catch(e){console.error(e.message);process.exitCode=1;}finally{db?.close();}
