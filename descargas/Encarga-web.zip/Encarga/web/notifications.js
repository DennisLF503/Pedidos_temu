import {randomUUID} from 'node:crypto';
export const channels = ['email', 'sms', 'whatsapp'];
export function createNotifications(db, {env = process.env, sendFetch = fetch} = {}) {
  db.exec(`CREATE TABLE IF NOT EXISTS notification_settings (teacher TEXT PRIMARY KEY REFERENCES teachers(id), settings TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS notifications (id TEXT PRIMARY KEY, teacher TEXT NOT NULL REFERENCES teachers(id), order_id TEXT NOT NULL REFERENCES orders(id), channel TEXT NOT NULL, destination TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL DEFAULT 0, provider_id TEXT, error TEXT, created TEXT NOT NULL, UNIQUE(order_id, teacher, channel));`);
  const oldSchema=db.prepare("SELECT sql FROM sqlite_master WHERE name='notifications'").get().sql;
  if(/UNIQUE\(order_id,\s*channel\)/.test(oldSchema)) {
    db.exec(`BEGIN; ALTER TABLE notifications RENAME TO notifications_legacy;
      CREATE TABLE notifications (id TEXT PRIMARY KEY, teacher TEXT NOT NULL REFERENCES teachers(id), order_id TEXT NOT NULL REFERENCES orders(id), channel TEXT NOT NULL, destination TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL DEFAULT 0, provider_id TEXT, error TEXT, created TEXT NOT NULL, UNIQUE(order_id, teacher, channel));
      INSERT INTO notifications SELECT * FROM notifications_legacy; DROP TABLE notifications_legacy; COMMIT;`);
  }
  const defaults = () => Object.fromEntries(channels.map(c => [c, {enabled:false, destination:''}]));
  const configured = channel => channel === 'email' ? Boolean(env.RESEND_API_KEY && env.NOTIFY_EMAIL_FROM) : Boolean(env.TWILIO_ACCOUNT_SID && env.TWILIO_AUTH_TOKEN && (channel === 'sms' ? env.TWILIO_SMS_FROM : env.TWILIO_WHATSAPP_FROM && env.TWILIO_WHATSAPP_CONTENT_SID));
  const settings = id => {const row=db.prepare('SELECT settings FROM notification_settings WHERE teacher=?').get(id);return row?JSON.parse(row.settings):defaults();};
  function save(id, input) {
    if (!input || channels.some(c => !input[c] || typeof input[c].enabled !== 'boolean' || typeof input[c].destination !== 'string' || input[c].destination.length > 254)) throw new Error('Revisa los datos de los tres canales.');
    const value=defaults();
    for (const c of channels) {
      const destination=input[c].destination.trim();
      if ((destination || input[c].enabled) && !(c === 'email' ? /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(destination) : /^\+[1-9]\d{7,14}$/.test(destination))) throw new Error(c==='email'?'Escribe un correo válido.':'Usa el formato internacional, por ejemplo +50371234567.');
      value[c]={enabled:input[c].enabled,destination};
    }
    if(channels.some(c=>value[c].enabled) && input.consent !== true) throw new Error('Confirma que autorizas recibir estos avisos en tus contactos.');
    const previous=settings(id);
    db.prepare('INSERT OR REPLACE INTO notification_settings VALUES (?,?)').run(id,JSON.stringify(value));
    for(const c of channels) if(!value[c].enabled || previous[c].destination!==value[c].destination) db.prepare("UPDATE notifications SET status='cancelled',error=NULL WHERE teacher=? AND channel=? AND status IN ('pending','unconfigured')").run(id,c);
    return value;
  }
  function enqueue(order) {
    const preferences=settings(order.teacher);
    const payload=JSON.stringify({student:order.student,product:order.product,total:(order.price*order.quantity/100).toFixed(2),reference:order.id});
    for(const c of channels) if(preferences[c].enabled) db.prepare('INSERT INTO notifications (id,teacher,order_id,channel,destination,payload,status,created) VALUES (?,?,?,?,?,?,?,?)').run(randomUUID(),order.teacher,order.id,c,preferences[c].destination,payload,configured(c)?'pending':'unconfigured',new Date().toISOString());
  }
  const history=id=>db.prepare('SELECT id,order_id,channel,status,attempts,error,created FROM notifications WHERE teacher=? ORDER BY created DESC LIMIT 20').all(id);
  let running=false;
  async function dispatch() {
    if(running)return;running=true;
    try {
      // A crash after submission is uncertain; do not automatically duplicate SMS/WhatsApp.
      // Missing providers must not starve ready channels behind their queued rows.
      for(const c of channels){
        if(configured(c)) db.prepare("UPDATE notifications SET status='pending',error=NULL WHERE channel=? AND status='unconfigured'").run(c);
        else db.prepare("UPDATE notifications SET status='unconfigured',error='Falta configurar el proveedor en el servidor.' WHERE channel=? AND status='pending'").run(c);
      }
      const rows=db.prepare("SELECT * FROM notifications WHERE status='pending' AND next_at<=? ORDER BY created LIMIT 10").all(Date.now());
      for(const row of rows){
        if(!configured(row.channel)){db.prepare("UPDATE notifications SET status='unconfigured',error='Falta configurar el proveedor en el servidor.' WHERE id=?").run(row.id);continue;}
        // Disabling a channel cancels queued messages, but cannot recall a message already accepted.
        if(!db.prepare('SELECT teacher FROM store_members WHERE teacher=? AND active=1').get(row.teacher) || !settings(row.teacher)[row.channel].enabled){db.prepare("UPDATE notifications SET status='cancelled',error=NULL WHERE id=?").run(row.id);continue;}
        db.prepare("UPDATE notifications SET status='sending',attempts=attempts+1,error=NULL WHERE id=?").run(row.id);
        const data=JSON.parse(row.payload);
        const text=`Nuevo encargo #${data.reference}: ${data.student}. Producto: ${data.product}. Total: USD ${data.total}. Revisa Encarga.`;
        let url,options;
        if(row.channel==='email'){
          url='https://api.resend.com/emails';options={method:'POST',headers:{Authorization:`Bearer ${env.RESEND_API_KEY}`,'Content-Type':'application/json','Idempotency-Key':row.id},body:JSON.stringify({from:env.NOTIFY_EMAIL_FROM,to:[row.destination],subject:`Nuevo encargo #${data.reference}`,text})};
        }else{
          url=`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(env.TWILIO_ACCOUNT_SID)}/Messages.json`;
          const body=new URLSearchParams(row.channel==='sms'?{From:env.TWILIO_SMS_FROM,To:row.destination,Body:text}:{From:'whatsapp:'+env.TWILIO_WHATSAPP_FROM.replace(/^whatsapp:/,''),To:'whatsapp:'+row.destination,ContentSid:env.TWILIO_WHATSAPP_CONTENT_SID,ContentVariables:JSON.stringify({'1':data.student,'2':data.product,'3':data.total,'4':data.reference})});
          options={method:'POST',headers:{Authorization:'Basic '+Buffer.from(env.TWILIO_ACCOUNT_SID+':'+env.TWILIO_AUTH_TOKEN).toString('base64'),'Content-Type':'application/x-www-form-urlencoded'},body};
        }
        try{
          const response=await sendFetch(url,{...options,signal:AbortSignal.timeout(15000)});
          if(!response.ok){
            const retry=response.status===429 && row.attempts<2;
            db.prepare('UPDATE notifications SET status=?,next_at=?,error=? WHERE id=?').run(retry?'pending':'failed',Date.now()+60000,`El proveedor rechazó el aviso (HTTP ${response.status}). Revisa la configuración y los límites.`,row.id);continue;
          }
          const result=await response.json();
          const providerId=result.id||result.sid;
          if(typeof providerId!=='string' || !providerId || result.error_code){db.prepare("UPDATE notifications SET status='unknown',error='Respuesta no concluyente del proveedor. Comprueba su panel.' WHERE id=?").run(row.id);continue;}
          db.prepare("UPDATE notifications SET status='accepted',provider_id=?,error=NULL WHERE id=?").run(providerId,row.id);
        }catch{
          db.prepare("UPDATE notifications SET status='unknown',error='No se pudo confirmar la respuesta del proveedor. No se reintentará automáticamente para evitar duplicados.' WHERE id=?").run(row.id);
        }
      }
    }finally{running=false;}
  }
  // Pending calls from a previous process might already have reached the provider.
  db.prepare("UPDATE notifications SET status='unknown',error='Envío interrumpido; comprueba el proveedor antes de reenviar.' WHERE status='sending'").run();
  return {settings,save,enqueue,history,dispatch,providers:()=>Object.fromEntries(channels.map(c=>[c,configured(c)]))};
}
