import express from 'express';
import {installCommerce} from './commerce.js';
import {createNotifications} from './notifications.js';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));
export function createApp(dbPath = process.env.DB_PATH || path.resolve('data/beta.sqlite'), { receivingPhone = process.env.RECEIVING_TEACHER_PHONE || '', notificationOptions } = {}) {
  if (dbPath !== ':memory:') mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS teachers (id TEXT PRIMARY KEY, name TEXT NOT NULL, classroom TEXT NOT NULL, phone TEXT UNIQUE NOT NULL, password TEXT NOT NULL, code TEXT UNIQUE NOT NULL);
    CREATE TABLE IF NOT EXISTS store_members (teacher TEXT PRIMARY KEY REFERENCES teachers(id), store_id TEXT NOT NULL REFERENCES teachers(id), active INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, teacher TEXT NOT NULL REFERENCES teachers(id), expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, teacher TEXT NOT NULL REFERENCES teachers(id), student TEXT NOT NULL, section TEXT NOT NULL, product TEXT NOT NULL, price INTEGER NOT NULL, quantity INTEGER NOT NULL, link TEXT NOT NULL, image TEXT NOT NULL, note TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pendiente', created TEXT NOT NULL);
  `);
  const notifications = createNotifications(db, notificationOptions);
  const app = express();
  app.disable('x-powered-by');
  app.use((req,res,next)=>{
    res.set({'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','Permissions-Policy':'camera=(), microphone=(), geolocation=()'});
    if(process.env.NODE_ENV==='production')res.set('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'");
    next();
  });
  app.use(express.json({ limit: '3mb' }));
  app.use('/api', (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    if (!['GET', 'HEAD'].includes(req.method) && req.headers.origin && new URL(req.headers.origin).host !== req.headers.host) return res.status(403).json({ error: 'Origen no permitido.' });
    next();
  });
  const attempts = new Map();
  const limit = (req, res, next) => {
    for(const [ip,entry] of attempts)if(entry.until<Date.now())attempts.delete(ip);
    const key = req.socket.remoteAddress;
    const entry = attempts.get(key);
    if (!entry || entry.until < Date.now()) { attempts.set(key, { count: 1, until: Date.now() + 600000 }); return next(); }
    if (++entry.count > 60) return res.status(429).json({ error: 'Demasiados intentos. Espera unos minutos.' });
    next();
  };
  const hash = text => createHash('sha256').update(text).digest('hex');
  const publicTeacher = t => ({ name: 'Administrador', classroom: 'Administrador', receivesOrders: Boolean(membership(t.id)), ordersOpen: receiver() ? ordersAreOpen(receiver().id) : false });
  const session = (res, id, req) => {
    const token = randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions VALUES (?, ?, ?)').run(hash(token), id, Date.now() + 7 * 86400000);
    res.set('Set-Cookie', `encarga_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800${req.secure || req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : ''}`);
  };
  const requireTeacher = (req, res, next) => {
    const token = req.headers.cookie?.split(';').map(x => x.trim()).find(x => x.startsWith('encarga_session='))?.slice(16);
    const row = token && db.prepare('SELECT teachers.* FROM sessions JOIN teachers ON sessions.teacher=teachers.id WHERE token=? AND expires>?').get(hash(token), Date.now());
    if (!row) return res.status(401).json({ error: 'Inicia sesión para continuar.' });
    const member=membership(row.id);
    if(!member)return res.status(403).json({error:'Este acceso no está autorizado o está desactivado.'});
    req.teacher = row; req.storeId=member.store_id; next();
  };
  const {record,atomic}=installCommerce({app,db,requireTeacher,limit});
  app.get('/api/health', (req,res)=>{db.prepare('SELECT 1').get();res.json({ok:true});});
  const text = (value, max) => typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max;
  const normalizePhone = value => typeof value === 'string' ? value.replace(/[\s()+-]/g, '') : '';
  // Keep existing accounts/orders intact. A single legacy account is safe to
  // select automatically; several legacy accounts require an explicit operator choice.
  const existingTeachers = db.prepare('SELECT id FROM teachers LIMIT 2').all();
  if (existingTeachers.length === 1) db.prepare("INSERT OR IGNORE INTO app_settings VALUES ('receiving_teacher', ?)").run(existingTeachers[0].id);
  const receiver = () => receivingPhone
    ? db.prepare('SELECT * FROM teachers WHERE phone=?').get(normalizePhone(receivingPhone))
    : db.prepare("SELECT teachers.* FROM teachers JOIN app_settings ON teachers.id=app_settings.value WHERE app_settings.key='receiving_teacher'").get();
  // The original receiving account is a stable store ID, not a public identity.
  const initialStore=receiver();
  if(initialStore) db.prepare('INSERT OR IGNORE INTO store_members (teacher,store_id) VALUES (?,?)').run(initialStore.id,initialStore.id);
  const membership = id => {const store=receiver();return store && db.prepare('SELECT * FROM store_members WHERE teacher=? AND store_id=? AND active=1').get(id,store.id);};
  const ordersAreOpen = id => db.prepare('SELECT value FROM app_settings WHERE key=?').get('orders_open:' + id)?.value !== 'false';
  app.patch('/api/school', requireTeacher, (req, res) => {
    if (typeof req.body.ordersOpen !== 'boolean') return res.status(400).json({error: 'Indica si quieres abrir o cerrar los encargos.'});
    atomic(()=>{db.prepare('INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)').run('orders_open:' + req.storeId, String(req.body.ordersOpen));record(req.storeId,req.teacher.id,req.body.ordersOpen?'Encargos abiertos':'Encargos cerrados','Disponibilidad de la tienda');});
    res.json({ordersOpen: req.body.ordersOpen});
  });
  app.get('/api/school', (req, res) => {
    const teacher = receiver();
    res.json({ ready: Boolean(teacher), ordersOpen: Boolean(teacher) && ordersAreOpen(teacher.id), registrationOpen: !db.prepare('SELECT id FROM teachers LIMIT 1').get(),
      ...(teacher ? { name: 'Administrador' } : {}) });
  });
  app.post('/api/register', limit, (req, res) => {
    const { password } = req.body;
    const phone = normalizePhone(req.body.phone);
    if (!/^\d{8,15}$/.test(phone) || typeof password !== 'string' || password.length < 8 || password.length > 128) return res.status(400).json({ error: 'Revisa los campos. Usa un teléfono válido y una contraseña de 8 a 128 caracteres.' });
    if (db.prepare('SELECT id FROM teachers WHERE phone=?').get(phone)) return res.status(409).json({ error: 'Este teléfono ya tiene una cuenta. Inicia sesión.' });
    if (db.prepare('SELECT id FROM teachers LIMIT 1').get()) return res.status(409).json({ error: 'La cuenta del Administrador ya está creada. Inicia sesión.' });
    if (receivingPhone && normalizePhone(receivingPhone) !== phone) return res.status(400).json({ error: 'Este teléfono no coincide con el configurado para el Administrador.' });
    const id = randomBytes(16).toString('hex'), salt = randomBytes(16).toString('hex');
    const code = randomBytes(4).toString('hex').toUpperCase();
    db.prepare('INSERT INTO teachers VALUES (?, ?, ?, ?, ?, ?)').run(id, 'Administrador', 'Administrador', phone, salt + ':' + scryptSync(password, salt, 64).toString('hex'), code);
    db.prepare("INSERT OR REPLACE INTO app_settings VALUES ('receiving_teacher', ?)").run(id);
    db.prepare('INSERT INTO store_members (teacher,store_id) VALUES (?,?)').run(id,id);
    session(res, id, req);
    res.status(201).json(publicTeacher(db.prepare('SELECT * FROM teachers WHERE id=?').get(id)));
  });
  app.post('/api/login', limit, (req, res) => {
    const teacher = db.prepare('SELECT * FROM teachers WHERE phone=?').get(normalizePhone(req.body.phone));
    const password = req.body.password;
    if (typeof password !== 'string' || password.length > 128) return res.status(400).json({error: 'Contraseña no válida.'});
    const [salt, digest] = teacher ? teacher.password.split(':') : ['invalid-salt', '00'.repeat(64)];
    const valid = timingSafeEqual(scryptSync(password, salt, 64), Buffer.from(digest, 'hex'));
    if (!teacher || !valid) return res.status(401).json({error: 'Teléfono o contraseña incorrectos.'});
    if(!membership(teacher.id))return res.status(403).json({error:'Este acceso no está autorizado o está desactivado.'});
    session(res, teacher.id, req); res.json(publicTeacher(teacher));
  });
  app.get('/api/me', requireTeacher, (req, res) => res.json(publicTeacher(req.teacher)));
  app.post('/api/logout', (req, res) => {
    const token = req.headers.cookie?.split(';').map(x => x.trim()).find(x => x.startsWith('encarga_session='))?.slice(16);
    if (token) db.prepare('DELETE FROM sessions WHERE token=?').run(hash(token));
    res.set('Set-Cookie', 'encarga_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'); res.json({ok: true});
  });
  app.get('/api/admins', requireTeacher, (req,res) => {
    const rows=db.prepare('SELECT teachers.id,teachers.phone,store_members.active FROM teachers JOIN store_members ON store_members.teacher=teachers.id WHERE store_members.store_id=? ORDER BY teachers.rowid').all(req.storeId);
    res.json(rows.map(row=>({id:row.id,label:'Administrador',phoneHint:'•••• '+row.phone.slice(-4),active:Boolean(row.active),self:row.id===req.teacher.id})));
  });
  app.post('/api/admins', requireTeacher, limit, (req,res) => {
    const phone=normalizePhone(req.body.phone);const {password}=req.body;
    if(!/^\d{8,15}$/.test(phone)||typeof password!=='string'||password.length<8||password.length>128)return res.status(400).json({error:'Usa un teléfono válido y una contraseña de 8 a 128 caracteres.'});
    if(db.prepare('SELECT id FROM teachers WHERE phone=?').get(phone))return res.status(409).json({error:'Ese teléfono ya tiene un acceso. Usa otro o reactiva el existente.'});
    const id=randomBytes(16).toString('hex'),salt=randomBytes(16).toString('hex');
    db.exec('BEGIN');try{
      db.prepare('INSERT INTO teachers VALUES (?,?,?,?,?,?)').run(id,'Administrador','Administrador',phone,salt+':'+scryptSync(password,salt,64).toString('hex'),randomBytes(8).toString('hex'));
      db.prepare('INSERT INTO store_members (teacher,store_id) VALUES (?,?)').run(id,req.storeId);record(req.storeId,req.teacher.id,'Acceso creado','Acceso '+id.slice(0,8));db.exec('COMMIT');
    }catch(error){db.exec('ROLLBACK');throw error;}
    res.status(201).json({id,label:'Administrador'});
  });
  app.patch('/api/admins/:id', requireTeacher, (req,res) => {
    if(typeof req.body.active!=='boolean')return res.status(400).json({error:'Indica si quieres activar o desactivar el acceso.'});
    if(req.params.id===req.teacher.id)return res.status(400).json({error:'No puedes desactivar tu propio acceso.'});
    const member=db.prepare('SELECT * FROM store_members WHERE teacher=? AND store_id=?').get(req.params.id,req.storeId);
    if(!member)return res.status(404).json({error:'Acceso no encontrado en esta tienda.'});
    atomic(()=>{
      db.prepare('UPDATE store_members SET active=? WHERE teacher=? AND store_id=?').run(req.body.active?1:0,req.params.id,req.storeId);
      if(!req.body.active){
        db.prepare('DELETE FROM sessions WHERE teacher=?').run(req.params.id);
        db.prepare("UPDATE notifications SET status='cancelled',error=NULL WHERE teacher=? AND status IN ('pending','unconfigured')").run(req.params.id);
      }
      if(Boolean(member.active)!==req.body.active)record(req.storeId,req.teacher.id,req.body.active?'Acceso reactivado':'Acceso desactivado','Acceso '+req.params.id.slice(0,8));
    });
    res.json({active:req.body.active});
  });
  app.post('/api/account/password',requireTeacher,limit,(req,res)=>{
    const {currentPassword,password}=req.body;
    if(typeof currentPassword!=='string'||currentPassword.length>128||typeof password!=='string'||password.length<8||password.length>128)return res.status(400).json({error:'Usa tu contraseña actual y una nueva de 8 a 128 caracteres.'});
    const [oldSalt,oldHash]=req.teacher.password.split(':');
    if(!oldHash||!timingSafeEqual(scryptSync(currentPassword,oldSalt,64),Buffer.from(oldHash,'hex')))return res.status(403).json({error:'La contraseña actual no es correcta.'});
    const salt=randomBytes(16).toString('hex');
    atomic(()=>{db.prepare('UPDATE teachers SET password=? WHERE id=?').run(salt+':'+scryptSync(password,salt,64).toString('hex'),req.teacher.id);db.prepare('DELETE FROM sessions WHERE teacher=?').run(req.teacher.id);record(req.storeId,req.teacher.id,'Contraseña actualizada','Sesiones anteriores cerradas');});
    session(res,req.teacher.id,req);res.json({ok:true});
  });
  app.get('/api/notifications', requireTeacher, (req, res) => {
    res.json({settings:notifications.settings(req.teacher.id),providers:notifications.providers(),history:notifications.history(req.teacher.id)});
  });
  app.put('/api/notifications', requireTeacher, (req, res) => {
    try {res.json({settings:notifications.save(req.teacher.id,req.body)});}catch(error){res.status(400).json({error:error.message});}
  });
  app.post('/api/orders', limit, (req, res) => {
    const { student, section, product, price, quantity, link, image, note } = req.body;
    const teacher = receiver();
    if (!teacher) return res.status(503).json({error: 'Los encargos aún no están habilitados. El Administrador debe configurar su cuenta.'});
    if (!ordersAreOpen(teacher.id)) return res.status(409).json({code:'ORDERS_CLOSED', error:'El Administrador ha cerrado los encargos. Podrás enviar el tuyo cuando los vuelva a abrir.'});
    let validLink = false;
    try { const url = new URL(link); validLink = url.protocol === 'https:' && (url.hostname === 'temu.com' || url.hostname.endsWith('.temu.com')); } catch {}
    if (!text(student, 100) || (typeof section !== 'string' || section.length > 80) || !text(product, 180) || !Number.isInteger(price) || price <= 0 || price > 10000000 || !Number.isInteger(quantity) || quantity < 1 || quantity > 99 || !validLink || link.length > 2000 || typeof image !== 'string' || !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(image) || image.length > 2800000 || typeof note !== 'string' || note.length > 1000) return res.status(400).json({ error: 'Revisa los campos: imagen JPG/PNG/WebP de hasta 2 MB, enlace HTTPS de Temu y precio válido.' });
    const id = randomBytes(6).toString('hex').toUpperCase();
    // Order + outbox are one transaction; providers never block or undo the order.
    db.exec('BEGIN');
    try {
    db.prepare('INSERT INTO orders (id,teacher,student,section,product,price,quantity,link,image,note,created) VALUES (?,?,?,?,?,?,?,?,?,?,?)').run(id, teacher.id, student.trim(), section.trim(), product.trim(), price, quantity, link, image, note.trim(), new Date().toISOString());
      for(const member of db.prepare('SELECT teacher FROM store_members WHERE store_id=? AND active=1').all(teacher.id))notifications.enqueue({id,teacher:member.teacher,student:student.trim(),product:product.trim(),price,quantity});
      record(teacher.id,null,'Pedido recibido','Enviado por el cliente',id);
      db.exec('COMMIT');
    }catch(error){db.exec('ROLLBACK');throw error;}
    res.status(201).json({ id });
  });
  app.get('/api/orders', requireTeacher, (req, res) => res.json(db.prepare('SELECT orders.*, COALESCE((SELECT SUM(amount) FROM payments WHERE payments.order_id=orders.id AND payments.store_id=orders.teacher AND payments.reversed IS NULL),0) AS paid FROM orders WHERE teacher=? ORDER BY created DESC').all(req.storeId).map(({teacher, ...o}) => o)));
  app.patch('/api/orders/:id', requireTeacher, (req, res) => {
    if (!['Pendiente', 'Comprado', 'En camino', 'Entregado', 'Cancelado'].includes(req.body.status)) return res.status(400).json({error: 'Estado no válido.'});
    const order=db.prepare('SELECT * FROM orders WHERE id=? AND teacher=?').get(req.params.id,req.storeId);
    if(!order)return res.status(404).json({error:'Pedido no encontrado.'});
    if(order.status!==req.body.status)atomic(()=>{
      db.prepare('UPDATE orders SET status=? WHERE id=? AND teacher=?').run(req.body.status,order.id,req.storeId);
      record(req.storeId,req.teacher.id,'Estado actualizado',order.status+' → '+req.body.status,order.id);
    });
    res.json({ok: true});
  });
  app.use('/api', (req, res) => res.status(404).json({error:'Ruta no encontrada.'}));
  app.use((err, req, res, next) => { console.error(err.message); res.status(err.status === 413 ? 413 : 400).json({error: err.status === 413 ? 'La imagen es demasiado grande. Máximo 2 MB.' : 'No se pudo procesar la solicitud.'}); });
  return { app, db, notifications };
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const {app,notifications} = createApp();
  const notificationTimer=setInterval(()=>notifications.dispatch().catch(()=>console.error('No se pudo procesar la cola de avisos.')),5000);
  notificationTimer.unref();
  notifications.dispatch().catch(()=>{});
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve('dist')));
    app.get('/{*path}', (req, res) => res.sendFile(path.resolve('dist/index.html')));
  } else {
    const {createServer} = await import('vite');
    const vite = await createServer({configFile: path.join(dir, 'vite.config.js'), server: {middlewareMode: true}, appType: 'spa'});
    app.use(vite.middlewares);
  }
  app.listen(Number(process.env.PORT || 3000), '0.0.0.0', () => console.log('Encarga beta lista en el puerto ' + (process.env.PORT || 3000)));
}
