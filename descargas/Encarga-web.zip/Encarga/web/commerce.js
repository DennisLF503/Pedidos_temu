import {randomBytes} from 'node:crypto';

// All money is integer USD cents. Payments are a manual ledger, not a gateway.
export function installCommerce({app, db, requireTeacher, limit}) {
  db.exec(`CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, store_id TEXT NOT NULL REFERENCES teachers(id),
    order_id TEXT REFERENCES orders(id), actor TEXT REFERENCES teachers(id), action TEXT NOT NULL,
    detail TEXT NOT NULL, created TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS audit_store_order ON audit_events(store_id,order_id,id);
    CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(id), store_id TEXT NOT NULL REFERENCES teachers(id),
    amount INTEGER NOT NULL CHECK(amount>0), method TEXT NOT NULL, note TEXT NOT NULL, actor TEXT NOT NULL REFERENCES teachers(id),
    request_key TEXT NOT NULL, created TEXT NOT NULL, reversed TEXT, reversal_note TEXT,
    UNIQUE(store_id,request_key));
    CREATE INDEX IF NOT EXISTS payments_order ON payments(store_id,order_id);`);
  const atomic = fn => {db.exec('BEGIN IMMEDIATE');try{const value=fn();db.exec('COMMIT');return value;}catch(e){db.exec('ROLLBACK');throw e;}};
  const record = (store,actor,action,detail,order=null) => db.prepare('INSERT INTO audit_events (store_id,order_id,actor,action,detail,created) VALUES (?,?,?,?,?,?)').run(store,order,actor,action,detail,new Date().toISOString());
  const order = req => db.prepare('SELECT * FROM orders WHERE id=? AND teacher=?').get(req.params.id,req.storeId);
  const balance = o => {const paid=db.prepare('SELECT COALESCE(SUM(amount),0) n FROM payments WHERE order_id=? AND store_id=? AND reversed IS NULL').get(o.id,o.teacher).n;return {total:o.price*o.quantity,paid,balance:o.price*o.quantity-paid};};
  app.get('/api/orders/:id/ledger',requireTeacher,(req,res)=>{
    const o=order(req);if(!o)return res.status(404).json({error:'Pedido no encontrado.'});
    res.json({...balance(o),payments:db.prepare('SELECT id,amount,method,note,created,reversed,reversal_note FROM payments WHERE order_id=? AND store_id=? ORDER BY created DESC,id').all(o.id,req.storeId),history:db.prepare('SELECT id,action,detail,created,substr(actor,1,8) AS actorRef,actor=? AS self FROM audit_events WHERE store_id=? AND order_id=? ORDER BY id DESC LIMIT 100').all(req.teacher.id,req.storeId,o.id)});
  });
  app.get('/api/activity',requireTeacher,(req,res)=>res.json(db.prepare('SELECT id,order_id,action,detail,created,substr(actor,1,8) AS actorRef,actor=? AS self FROM audit_events WHERE store_id=? ORDER BY id DESC LIMIT 100').all(req.teacher.id,req.storeId)));
  app.post('/api/orders/:id/payments',requireTeacher,limit,(req,res)=>{
    const o=order(req);if(!o)return res.status(404).json({error:'Pedido no encontrado.'});
    const {amount,method,note='',requestKey}=req.body;
    if(!Number.isSafeInteger(amount)||amount<=0||!['Efectivo','Transferencia','Otro'].includes(method)||typeof note!=='string'||note.length>300||typeof requestKey!=='string'||!/^[a-zA-Z0-9-]{16,80}$/.test(requestKey))return res.status(400).json({error:'Revisa el monto, método y referencia del abono.'});
    const existing=db.prepare('SELECT * FROM payments WHERE store_id=? AND request_key=?').get(req.storeId,requestKey);
    if(existing){if(existing.order_id!==o.id||existing.amount!==amount||existing.method!==method||existing.note!==note.trim())return res.status(409).json({error:'La referencia ya corresponde a otro registro.'});return res.json({id:existing.id});}
    if(o.status==='Cancelado')return res.status(409).json({error:'No se pueden registrar abonos en un pedido cancelado.'});
    if(amount>balance(o).balance)return res.status(409).json({error:'El abono supera el saldo pendiente. Actualiza los datos.'});
    const id=randomBytes(16).toString('hex');
    atomic(()=>{db.prepare('INSERT INTO payments (id,order_id,store_id,amount,method,note,actor,request_key,created) VALUES (?,?,?,?,?,?,?,?,?)').run(id,o.id,req.storeId,amount,method,note.trim(),req.teacher.id,requestKey,new Date().toISOString());record(req.storeId,req.teacher.id,'Abono registrado',`${(amount/100).toFixed(2)} USD · ${method}`,o.id);});
    res.status(201).json({id});
  });
  app.post('/api/orders/:id/payments/:payment/reverse',requireTeacher,limit,(req,res)=>{
    const o=order(req);if(!o)return res.status(404).json({error:'Pedido no encontrado.'});
    const payment=db.prepare('SELECT * FROM payments WHERE id=? AND order_id=? AND store_id=?').get(req.params.payment,o.id,req.storeId);
    if(!payment)return res.status(404).json({error:'Abono no encontrado.'});
    const {reason}=req.body;if(typeof reason!=='string'||!reason.trim()||reason.length>300)return res.status(400).json({error:'Indica el motivo de la anulación (máximo 300 caracteres).'});
    if(!payment.reversed)atomic(()=>{db.prepare('UPDATE payments SET reversed=?,reversal_note=? WHERE id=?').run(new Date().toISOString(),reason.trim(),payment.id);record(req.storeId,req.teacher.id,'Abono anulado',`${(payment.amount/100).toFixed(2)} USD · ${reason.trim()}`,o.id);});
    res.json({ok:true});
  });
  return {record,atomic};
}
