import React, {useState, useEffect, useRef} from 'react';
import {createRoot} from 'react-dom/client';
import {Home, ShoppingBag, GraduationCap, LayoutDashboard, ArrowUpRight, ArrowRight, Plus, Check, CheckCheck, ShieldCheck, Link as LinkIcon, ImagePlus, X, Copy, LogOut, Search, Package, Truck, Clock3, Users, Wallet, ChevronDown, Download, Menu, CircleHelp, ExternalLink, LoaderCircle, Smartphone, Headphones, Backpack, Footprints, RefreshCw, CheckCircle2} from 'lucide-react';
import '@fontsource-variable/geist';
import './style.css';
import './theme.css';
import './app-layout.css';
import NotificationSettings from './NotificationSettings.jsx';
import AdminManagement from './AdminManagement.jsx';
import Modal from './Modal.jsx';
import OrderLedger from './OrderLedger.jsx';
import StoreTools from './StoreTools.jsx';
const statuses = ['Pendiente', 'Comprado', 'En camino', 'Entregado', 'Cancelado'];
const usd = cents => new Intl.NumberFormat('en-US', {style:'currency', currency:'USD'}).format(cents/100);
async function api(path, options={}) {
  const res = await fetch('/api'+path, {credentials:'same-origin', ...options, headers:{'Content-Type':'application/json', ...options.headers}, body: options.body ? JSON.stringify(options.body) : undefined});
  const data = await res.json();
  if (!res.ok) throw Object.assign(new Error(data.error || 'No se pudo completar la solicitud.'), {code:data.code, status:res.status});
  return data;
}
const demos = [
  {id:'DEMO-001',student:'Valeria Hernández',section:'Retiro en tienda',product:'Audífonos inalámbricos',price:850,quantity:1,status:'Pendiente',kind:'audio',created:new Date().toISOString(),link:'https://www.temu.com',note:'En color blanco, por favor.',image:''},
  {id:'DEMO-002',student:'Diego Martínez',section:'Entrega a domicilio',product:'Mochila para la universidad',price:1290,quantity:1,status:'Comprado',kind:'bag',created:new Date().toISOString(),link:'https://www.temu.com',note:'Color verde.',image:''},
  {id:'DEMO-003',student:'Sofía López',section:'Retiro en tienda',product:'Tenis deportivos blancos',price:1575,quantity:1,status:'En camino',kind:'shoes',created:new Date().toISOString(),link:'https://www.temu.com',note:'Talla 38.',image:''},
  {id:'DEMO-004',student:'Andrés Rodríguez',section:'Retiro en tienda',product:'Funda para teléfono',price:325,quantity:2,status:'Entregado',kind:'phone',created:new Date().toISOString(),link:'https://www.temu.com',note:'Dos fundas azules.',image:''},
];
function App(){
  const [page,setPage]=useState(()=>(new URLSearchParams(location.search).has('grupo')||new URLSearchParams(location.search).has('pedido'))?'student':'home');
  const [teacher,setTeacher]=useState(null);
  const [checking,setChecking]=useState(true);
  const [sending,setSending]=useState(false);
  const [demo,setDemo]=useState(false);
  const [toast,setToast]=useState('');
  const [install,setInstall]=useState(null);
  const [installHelp,setInstallHelp]=useState(false);
  const timer=useRef();
  const notify = text => {setToast(text); clearTimeout(timer.current);timer.current=setTimeout(()=>setToast(''),4500);};
  useEffect(()=>{
    api('/me').then(setTeacher).catch(()=>{}).finally(()=>setChecking(false));
    const handler=e=>{e.preventDefault();setInstall(e);};window.addEventListener('beforeinstallprompt',handler);
    if('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
    return ()=>{window.removeEventListener('beforeinstallprompt',handler);clearTimeout(timer.current);};
  },[]);
  const navigate=p=>{setPage(p);setDemo(false);window.scrollTo({top:0,behavior:'instant'});};
  const openDemo=()=>{setDemo(true);setPage('teacher');window.scrollTo({top:0,behavior:'instant'});};
  const doInstall=async()=>{if(install){await install.prompt();setInstall(null);}else setInstallHelp(true);};
  return <div className="app-shell app-mode">
    <div className="main-shell"><header className="topbar app-topbar">
      <button className="app-brand" disabled={sending} onClick={()=>navigate('home')} aria-label="Encarga · Ir al inicio"><span className="brand-icon"><ShoppingBag size={23}/></span><span>encarga<span className="brand-dot">.</span><small>{page==='home'?'Pedidos de la tienda':page==='student'?'Clientes':'Administrador'}</small></span></button>
      <div className="top-actions"><span className="beta-pill">BETA</span><button className="app-install secondary" disabled={sending} aria-label="Instalar aplicación" onClick={doInstall}><Download size={18}/><span>Instalar</span></button></div>
    </header>
      <main>
        {page==='home'?<HomeScreen onStudent={()=>navigate('student')} onTeacher={()=>navigate('teacher')} openDemo={openDemo}/>:page==='student'?<StudentForm onSending={setSending}/>: demo||teacher ? <TeacherDashboard key={demo?'demo':'real'} teacher={demo?{name:'Administrador',classroom:'Administrador',}:teacher} demo={demo} notify={notify} onExit={async()=>{if(demo){setDemo(false);}else{try{await api('/logout',{method:'POST'});setTeacher(null);}catch(e){notify(e.message);}}}}/>:<TeacherAuth checking={checking} onLogin={setTeacher} openDemo={openDemo}/>}
        <footer><span><ShoppingBag size={14}/> Encarga · Menos confusiones, más organización.</span><span>Una herramienta independiente. No afiliada a Temu.</span></footer>
      </main>
    </div>
    <nav className="app-bottom-nav" aria-label="Navegación principal">
      <button disabled={sending} aria-current={page==='home'?'page':undefined} className={page==='home'?'selected':''} onClick={()=>navigate('home')}><Home size={22}/><span>Inicio</span></button>
      <button disabled={sending} aria-current={page==='student'?'page':undefined} className={page==='student'?'selected':''} onClick={()=>navigate('student')}><ShoppingBag size={22}/><span>Clientes</span></button>
      <button disabled={sending} aria-current={page==='teacher'?'page':undefined} className={page==='teacher'?'selected':''} onClick={()=>navigate('teacher')}><ShieldCheck size={23}/><span>Administrador</span></button>
    </nav>
    {toast&&<div className="toast" role="status"><CheckCircle2 size={19}/>{toast}<button className="icon-btn" aria-label="Cerrar aviso" onClick={()=>setToast('')}><X size={16}/></button></div>}
    {installHelp&&<Modal title="Encarga en tu teléfono" onClose={()=>setInstallHelp(false)}><div className="install-help"><Smartphone size={42}/><p>Abre esta página en tu navegador y añádela a la pantalla de inicio.</p><h4>Android · Chrome</h4><p>Menú ⋮ → <strong>Instalar aplicación</strong> o <strong>Añadir a pantalla de inicio</strong>.</p><h4>iPhone · Safari</h4><p>Compartir → <strong>Añadir a pantalla de inicio</strong>.</p><p className="muted small">La instalación necesita HTTPS y puede no aparecer dentro de una vista previa integrada. Abre el enlace en una pestaña nueva. Para enviar pedidos necesitas internet.</p></div></Modal>}
  </div>;
}
function HomeScreen({onStudent,onTeacher,openDemo}){
  return <section className="app-home">
    <div className="home-heading"><h1>¿Qué quieres<br/>hacer hoy?</h1><p>Elige tu espacio.</p></div>
    <div className="home-actions">
      <button className="home-action" onClick={onStudent}><span className="home-action-icon"><ShoppingBag size={32}/></span><span className="home-action-copy"><span className="role-label">CLIENTE</span><strong>Hacer un encargo</strong><span>Envía un producto de Temu.</span></span><ArrowRight size={24}/></button>
      <button className="home-action" onClick={onTeacher}><span className="home-action-icon"><ShieldCheck size={34}/></span><span className="home-action-copy"><span className="role-label">Administrador</span><strong>Organizar pedidos</strong><span>Consulta y organiza la tienda.</span></span><ArrowRight size={24}/></button>
    </div>
    <button className="secondary home-demo" onClick={openDemo}><LayoutDashboard size={19}/>Explorar demo<ArrowUpRight size={17}/></button>
    <p className="home-beta">Beta de prueba · Necesitas internet para enviar y consultar pedidos.</p>
  </section>;
}
const blank={student:'',section:'',product:'',price:'',quantity:1,link:'',note:''};
function StudentForm({onSending}){
  const [form,setForm]=useState(blank);
  const [school,setSchool]=useState(null);
  const [loadingSchool,setLoadingSchool]=useState(true);
  const [schoolError,setSchoolError]=useState('');
  const [image,setImage]=useState('');
  const [readingImage,setReadingImage]=useState(false);
  const submitting=useRef(false);
  const successHeading=useRef();
  const [error,setError]=useState('');
  const [busy,setBusy]=useState(false);
  const [receipt,setReceipt]=useState(null);
  const [agreed,setAgreed]=useState(false);
  const fileRef=useRef();
  const set=(key,value)=>setForm(f=>({...f,[key]:value}));
  async function loadSchool(quiet=false){if(submitting.current)return;if(!quiet){setLoadingSchool(true);setSchoolError('');}try{setSchool(await api('/school'));setSchoolError('');}catch(e){if(!quiet){setSchool(null);setSchoolError('No pudimos conectar. Revisa tu conexión e intenta de nuevo.');}}finally{if(!quiet)setLoadingSchool(false);}}
  useEffect(()=>{loadSchool();const timer=setInterval(()=>loadSchool(true),15000);const onFocus=()=>loadSchool(true);window.addEventListener('focus',onFocus);return()=>{clearInterval(timer);window.removeEventListener('focus',onFocus);};},[]);
  useEffect(()=>{if(receipt) successHeading.current?.focus();},[receipt]);
  async function chooseFile(file){
    if(!file)return;
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>2*1024*1024){setError('Elige una imagen JPG, PNG o WebP de máximo 2 MB.');return;}
    setReadingImage(true);
    const reader=new FileReader();reader.onloadend=()=>setReadingImage(false);reader.onload=()=>{setImage(reader.result);setError('');};reader.onerror=()=>setError('No pudimos leer esa imagen. Intenta con otra.');reader.readAsDataURL(file);
  }
  async function submit(e){e.preventDefault();if(submitting.current||readingImage)return;setError('');
    if(!school?.ready){setError('Los encargos aún no están habilitados por el Administrador.');return;}
    if(!school.ordersOpen){setError('El Administrador ha cerrado los encargos por ahora.');return;}
    if(!image){setError('Añade una imagen del producto para evitar confusiones.');return;}
    if(!/^\d{1,6}([.,]\d{1,2})?$/.test(form.price)){setError('Escribe un precio válido, por ejemplo 8.50.');return;}
    if(!agreed){setError('Confirma que revisaste los detalles de tu encargo.');return;}
    const price=Math.round(Number(form.price.replace(',','.'))*100);
    submitting.current=true;setBusy(true);onSending(true);
    try{const data=await api('/orders',{method:'POST',body:{...form,price,quantity:Number(form.quantity),image}});setReceipt({...data,total:price*Number(form.quantity),product:form.product,student:form.student});window.scrollTo({top:0,behavior:'smooth'});}catch(e){setError(e.message);if(e.code==='ORDERS_CLOSED')setSchool(s=>({...s,ordersOpen:false}));}finally{submitting.current=false;setBusy(false);onSending(false);}
  }
  if(receipt)return <><div className="success-card"><span className="success-check"><Check size={42}/></span><span className="eyebrow">¡YA ESTÁ EN LA LISTA!</span><h1 ref={successHeading} tabIndex={-1}>Tu encargo llegó<br/>a buenas manos.</h1><p><strong>{receipt.student}</strong>, el Administrador ya puede ver los detalles.<br/>Enviar un encargo no confirma la compra.</p><div className="receipt"><span>Referencia del encargo<strong>#{receipt.id}</strong></span><span>Producto<strong>{receipt.product}</strong></span><span>Total estimado<strong>{usd(receipt.total)}</strong></span></div><p className="small muted">Guarda esta referencia. Coordina el pago y cualquier cambio directamente con el Administrador.</p><button className="primary" onClick={()=>{setReceipt(null);setForm(f=>({...blank,student:f.student,section:f.section}));setImage('');setAgreed(false);}}>Hacer otro encargo <Plus size={17}/></button></div></>;
  return <><div className="section-intro student-app-heading"><div><h2>Hacer un encargo</h2><p>Tus datos, tu producto y listo.</p></div><span className="step-badge">Fácil, rápido y sin confusiones</span></div>
  <div className="school-recipient" aria-live="polite">{loadingSchool?<span><LoaderCircle className="spin" size={16}/>Preparando formulario…</span>:school?.ready?<span><ShieldCheck size={18}/>Tu encargo llegará al <strong>Administrador</strong></span>:<div className="school-unavailable" role="alert"><p>{schoolError||'El Administrador aún no ha habilitado los encargos. Inténtalo más tarde.'}</p><button className="secondary" type="button" onClick={()=>loadSchool()}>Reintentar <RefreshCw size={16}/></button></div>}</div>
  {school?.ready&&!school.ordersOpen&&<div className="orders-closed-notice" role="status"><Package size={24}/><div><strong>Encargos cerrados por ahora</strong><p>El Administrador los abrirá cuando esté listo para recibir más pedidos. Si ya escribiste uno, tus datos se mantienen mientras sigas en esta pantalla.</p><button type="button" className="secondary" disabled={loadingSchool} onClick={()=>loadSchool()}>Comprobar disponibilidad <RefreshCw size={16}/></button></div></div>}
  <div className="student-grid"><form className="form-card" onSubmit={submit} aria-busy={busy}><fieldset className="order-fields" disabled={busy}>
    <div className="form-section"><SectionTitle number="01" title="Tus datos" sub="Tu nombre y una referencia opcional."/>
      <div className="field-grid"><Field label="Tu nombre completo" required value={form.student} maxLength={100} placeholder="¿Cómo te llamas?" onChange={e=>set('student',e.target.value)}/><Field label="Referencia de entrega" optional value={form.section} maxLength={80} placeholder="Ej. Retiro en tienda" onChange={e=>set('section',e.target.value)}/></div>
    </div>
    <div className="form-section"><SectionTitle number="02" title="Tu producto" sub="Copia el enlace y el precio de Temu."/>
      <Field label="Nombre del producto" required value={form.product} maxLength={180} placeholder="Ej. Audífonos inalámbricos blancos" onChange={e=>set('product',e.target.value)}/>
      <Field label="Enlace del producto en Temu" required type="url" value={form.link} maxLength={2000} placeholder="https://www.temu.com/..." icon={<LinkIcon size={17}/>} onChange={e=>set('link',e.target.value)}/>
      <div className="field-grid price-grid"><div><label htmlFor="price">Precio por unidad (USD) <b>*</b></label><div className="input-wrap"><span className="input-icon dollar">$</span><input id="price" required inputMode="decimal" placeholder="0.00" value={form.price} maxLength={9} onChange={e=>set('price',e.target.value)}/><span className="input-suffix">USD</span></div></div><Field label="Cantidad" required type="number" min="1" max="99" value={form.quantity} onChange={e=>set('quantity',e.target.value)}/></div>
      <label>Imagen del producto <b>*</b></label><input className="visually-hidden" ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" aria-label="Subir imagen del producto" onChange={e=>{chooseFile(e.target.files[0]);e.target.value='';}}/>
      {readingImage?<div className="image-reading" role="status"><LoaderCircle className="spin" size={24}/><span>Preparando imagen…</span></div>:image?<div className="image-preview"><img src={image} alt="Producto que vas a encargar"/><div><strong>Imagen lista</strong><button className="text-button" type="button" onClick={()=>fileRef.current.click()}>Cambiar imagen</button></div><button className="icon-btn" type="button" aria-label="Quitar imagen" onClick={()=>setImage('')}><X size={18}/></button></div>:<button type="button" className="upload-zone" onClick={()=>fileRef.current.click()} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();chooseFile(e.dataTransfer.files[0]);}}><span className="upload-icon"><ImagePlus size={23}/></span><strong>Añadir imagen</strong><small>JPG, PNG o WebP · Máximo 2 MB</small></button>}
      <details className="optional-details"><summary>Agregar talla, color o nota <Plus size={16}/></summary><Field label="Detalles que no se deben olvidar" optional multiline maxLength={1000} value={form.note} placeholder="Color, talla, modelo… ¡Que llegue justo lo que quieres!" onChange={e=>set('note',e.target.value)}/></details>
    </div>
    <div className="submit-section"><label className="checkbox-label"><input type="checkbox" required checked={agreed} onChange={e=>setAgreed(e.target.checked)}/><span>Revisé los datos de mi encargo. Entiendo que el precio puede cambiar antes de la compra.</span></label>{error&&<div className="error-box" role="alert">{error}</div>}<div className="submit-bottom"><span><ShieldCheck size={16}/>Solo el equipo administrador verá tus datos</span><button className="primary" type="submit" disabled={busy||readingImage||loadingSchool||!school?.ready||!school?.ordersOpen}>{busy?<><LoaderCircle className="spin" size={17}/>Enviando…</>:<>Enviar mi encargo <ArrowRight size={18}/></>}</button></div></div>
  </fieldset>{busy&&<div className="order-send-overlay"><OrderLoading sending/></div>}</form></div></>;
}
function OrderLoading({sending=false}){
  return <div className={'order-loading '+(sending?'sending':'')} role="status" aria-live="polite">
    <div className="loading-package" aria-hidden="true"><Package size={36}/><span className="loading-orbit"/></div>
    <strong>{sending?'Enviando tu encargo…':'Cargando pedidos…'}</strong>
    <p>{sending?'Estamos guardando el producto y su imagen.':'Buscando los encargos de la tienda.'}</p>
    <div className="loading-track" aria-hidden="true"><span/></div>
    {!sending&&<div className="loading-rows" aria-hidden="true">{[0,1,2].map(i=><div className="loading-row" key={i}><span/><div><span/><span/></div></div>)}</div>}
    {sending&&<small>Espera la confirmación antes de cerrar la app.</small>}
  </div>;
}
function SectionTitle({number,title,sub}){return <div className="section-title"><span>{number}</span><div><h3>{title}</h3><p>{sub}</p></div></div>;}
function Field({label,required,optional,multiline,icon,...props}){const id=React.useId();return <div className="field"><label htmlFor={id}>{label} {required&&<b>*</b>}{optional&&<span className="optional">Opcional</span>}</label>{multiline?<textarea id={id} rows={3} required={required} {...props}/>:icon?<div className="input-wrap"><span className="input-icon">{icon}</span><input id={id} required={required} {...props}/></div>:<input id={id} required={required} {...props}/>}</div>;}
function TeacherAuth({onLogin,checking,openDemo}){
 const [register,setRegister]=useState(false),[form,setForm]=useState({phone:'',password:''}),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const [registrationOpen,setRegistrationOpen]=useState(false);
 useEffect(()=>{api('/school').then(school=>setRegistrationOpen(school.registrationOpen)).catch(()=>{});},[]);
 const change=k=>e=>setForm(f=>({...f,[k]:e.target.value}));
 async function submit(e){e.preventDefault();setBusy(true);setError('');try{onLogin(await api(register?'/register':'/login',{method:'POST',body:form}));}catch(e){setError(e.message);}finally{setBusy(false);}}
 return <><div className="auth-layout"><section className="auth-copy"><span className="eyebrow">EL ESPACIO DE QUIEN LO HACE POSIBLE</span><h2>Menos chats.<br/>Más claridad.</h2><p>Organiza los encargos de la tienda sin mezclar nombres, precios o productos.</p>{[[Users,'Cada cliente, identificado','Nombre y referencia junto a cada producto.'],[Wallet,'Precios siempre a la vista','Importes por producto y un total por comprar.'],[Package,'Del encargo a la entrega','Actualiza el estado a medida que avanza.']].map(([Icon,title,text])=><div className="auth-feature" key={title}><span><Icon size={21}/></span><div><strong>{title}</strong><p>{text}</p></div></div>)}<button className="text-button" onClick={openDemo}>Quiero ver un ejemplo primero <ArrowRight size={17}/></button></section><form className="auth-card" onSubmit={submit}><span className="auth-card-icon"><ShieldCheck size={27}/></span><h2>Administrador</h2><p>{register?'Crea tu cuenta para recibir los encargos.':'Entra para poner cada pedido en su lugar.'}</p><div className="auth-tabs"><button type="button" className={!register?'selected':''} onClick={()=>{setRegister(false);setError('');}}>Iniciar sesión</button>{registrationOpen&&<button type="button" className={register?'selected':''} onClick={()=>{setRegister(true);setError('');}}>Crear cuenta</button>}</div><Field label="Número de teléfono" required type="tel" autoComplete="tel" maxLength={22} value={form.phone} onChange={change('phone')} placeholder="Ej. 7123 4567"/><Field label="Contraseña" required type="password" autoComplete={register?'new-password':'current-password'} minLength={register?8:1} maxLength={128} value={form.password} onChange={change('password')} placeholder={register?'Crea una contraseña de 8 caracteres o más':'Tu contraseña'}/>{register&&<p className="small muted">Elige una contraseña que no uses en otras cuentas. La app no verifica el teléfono. Si pierdes el acceso, la recuperación la gestiona el operador autorizado de la tienda.</p>}{error&&<div className="error-box" role="alert">{error}</div>}<button type="submit" className="primary full" disabled={busy||checking}>{busy||checking?<><LoaderCircle className="spin" size={18}/>Un momento…</>:<>{register?'Crear mi espacio':'Entrar a mi espacio'}<ArrowRight size={18}/></>}</button><p className="small muted">¿Olvidaste tu contraseña? Solicita la recuperación al responsable del sistema de tu tienda.</p><p className="auth-privacy"><ShieldCheck size={15}/>Contraseña protegida. Acceso solo a la tienda.</p></form></div></>;
}
function TeacherDashboard({teacher,demo,notify,onExit}){
 const [orders,setOrders]=useState(demo?demos:[]),[loading,setLoading]=useState(!demo),[error,setError]=useState(''),[query,setQuery]=useState(''),[filter,setFilter]=useState('Todos'),[selected,setSelected]=useState(null),[updating,setUpdating]=useState(false),[refresh,setRefresh]=useState(0);
 useEffect(()=>{if(demo)return;let cancelled=false;async function load(){try{const data=await api('/orders');if(!cancelled){setOrders(data);setError('');}}catch(e){if(!cancelled)setError(e.message);}finally{if(!cancelled)setLoading(false);}}load();const interval=setInterval(load,30000);return()=>{cancelled=true;clearInterval(interval);};},[demo,refresh]);
 const [ordersOpen,setOrdersOpen]=useState(demo?true:null);
 const [savingAvailability,setSavingAvailability]=useState(false);
 const [availabilityError,setAvailabilityError]=useState('');
 async function loadAvailability(){try{const school=await api('/school');setOrdersOpen(school.ordersOpen);setAvailabilityError('');}catch(e){setAvailabilityError('No pudimos consultar si los encargos están abiertos.');}}
 useEffect(()=>{if(demo||teacher.receivesOrders===false)return;loadAvailability();const timer=setInterval(loadAvailability,15000);return()=>clearInterval(timer);},[demo,teacher.receivesOrders]);
 async function toggleOrders(){if(savingAvailability)return;if(ordersOpen===null){loadAvailability();return;}setSavingAvailability(true);setAvailabilityError('');try{const next=!ordersOpen;if(!demo){const result=await api('/school',{method:'PATCH',body:{ordersOpen:next}});setOrdersOpen(result.ordersOpen);}else setOrdersOpen(next);notify(demo?'Cambio de ejemplo: no afecta los encargos reales.':next?'Encargos abiertos. Ya pueden enviar pedidos.':'Encargos cerrados. Los pedidos anteriores se conservan.');}catch(e){setAvailabilityError(e.message);}finally{setSavingAvailability(false);}}
 const pending=orders.filter(o=>o.status==='Pendiente');
 const shown=orders.filter(o=>(filter==='Todos'||o.status===filter)&&(o.student+' '+o.product+' '+o.section).toLowerCase().includes(query.toLowerCase()));
 const copy=async()=>{if(teacher.receivesOrders===false){notify('Esta cuenta antigua no es la destinataria de los nuevos encargos.');return;}if(demo){notify('Esta es una demo. El Administrador debe crear su cuenta para recibir encargos.');return;}const text=location.origin+'/?pedido=1';try{await navigator.clipboard.writeText(text);notify('Enlace de la app copiado. Los clientes pueden pedir sin códigos.');}catch{notify('No se pudo copiar. Comparte la dirección de esta app con tus clientes.');}};

 async function updateStatus(status){setUpdating(true);try{if(!demo)await api('/orders/'+selected.id,{method:'PATCH',body:{status}});setOrders(os=>os.map(o=>o.id===selected.id?{...o,status}:o));setSelected(o=>({...o,status}));notify(demo?'Estado actualizado solo en la demo.':'Estado actualizado.');}catch(e){notify(e.message);}finally{setUpdating(false);}}
 function exportCsv(){const cells=[['Referencia','Cliente','Referencia de entrega','Producto','Cantidad','Precio USD','Total USD','Abonado USD','Saldo USD','Estado','Enlace'],...shown.map(o=>[o.id,o.student,o.section,o.product,o.quantity,(o.price/100).toFixed(2),(o.price*o.quantity/100).toFixed(2),((o.paid||0)/100).toFixed(2),((o.price*o.quantity-(o.paid||0))/100).toFixed(2),o.status,o.link])];const csv='\uFEFF'+cells.map(row=>row.map(v=>'"'+String(v).replace(/^[=+@-]/,"'").replaceAll('"','""')+'"').join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));const a=document.createElement('a');a.href=url;a.download='encarga-pedidos.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 return <>{demo&&<div className="demo-banner"><span><span className="tiny-dot"/><strong>Estás en una demo</strong> · Estos pedidos son ficticios. Explora sin miedo.</span><button onClick={onExit}>Crear mi cuenta <ArrowRight size={15}/></button></div>}<div className="dashboard-heading"><div><span className="eyebrow">TU ESPACIO, TODO BAJO CONTROL</span><h1>Administrador</h1><p>Aquí empieza una compra sin confusiones.</p></div><button className="secondary" onClick={onExit}><LogOut size={16}/>{demo?'Salir de la demo':'Cerrar sesión'}</button></div><section className="group-banner"><div className="group-left"><span className="group-icon"><ShieldCheck size={25}/></span><div><strong>Administrador</strong><p>{teacher.receivesOrders===false?'Esta cuenta antigua conserva su registro, pero no recibe encargos nuevos.':'Los clientes envían sus encargos a la tienda.'}</p></div></div><div className="group-actions"><button className="secondary" onClick={copy}>Compartir app <ArrowUpRight size={16}/></button></div>
{teacher.receivesOrders!==false&&<div className="availability-control"><div><strong>{ordersOpen===null?'Consultando disponibilidad…':ordersOpen?'Encargos abiertos':'Encargos cerrados'}</strong><p>{ordersOpen===false?'No se reciben nuevos pedidos. Los anteriores se conservan.':'Puedes cerrar los encargos cuando vayas a realizar la compra.'}</p></div><button className="primary" onClick={toggleOrders} disabled={savingAvailability||(ordersOpen===null&&!availabilityError)}>{savingAvailability?<><LoaderCircle className="spin" size={17}/>Guardando…</>:ordersOpen===null?'Reintentar':ordersOpen?'Cerrar encargos':'Abrir encargos'}</button>{availabilityError&&<p className="error-box" role="alert">{availabilityError}</p>}</div>}
</section><div className="stats">{[[ShoppingBag,'Encargos recibidos',orders.length,'Todos los productos de la tienda','sage'],[Users,'Clientes',new Set(orders.map(o=>o.student.toLowerCase())).size,'Con al menos un encargo','blue'],[Clock3,'Por comprar',pending.length,'Pendientes de tu próxima compra','orange'],[Wallet,'Total por comprar',usd(pending.reduce((s,o)=>s+o.price*o.quantity,0)),'Estimado · Solo pedidos pendientes','purple']].map(([Icon,label,value,sub,color])=><div className="stat-card" key={label}><div className="stat-top"><span>{label}</span><span className={'stat-icon '+color}><Icon size={18}/></span></div><strong>{value}</strong><small>{sub}</small></div>)}</div><section className="management-grid" aria-label="Configuración de la tienda"><AdminManagement request={api} demo={demo}/><NotificationSettings request={api} demo={demo} editable={teacher.receivesOrders!==false}/></section><StoreTools request={api} demo={demo}/><section className="orders-panel"><div className="orders-title"><div><h2>Los encargos de la tienda <span>{orders.length}</span></h2><p>Cada nombre con su producto. Así de simple.</p></div><div className="orders-tools"><button className="icon-btn" aria-label="Actualizar pedidos" onClick={()=>{setLoading(true);if(demo){setLoading(false);notify('La demo ya está actualizada.');}else setRefresh(r=>r+1);}}><RefreshCw size={17}/></button><button className="secondary" onClick={exportCsv} disabled={!shown.length}><Download size={16}/>Exportar</button></div></div><div className="orders-filters"><div className="filter-tabs">{['Todos','Pendiente','Comprado','En camino','Entregado'].map(s=><button key={s} className={filter===s?'selected':''} onClick={()=>setFilter(s)}>{s==='Pendiente'?'Por comprar':s}{s==='Todos'&&<span>{orders.length}</span>}</button>)}<select aria-label="Más estados" value={filter==='Cancelado'?'Cancelado':''} onChange={e=>{if(e.target.value)setFilter(e.target.value);}}><option value="">Más</option><option>Cancelado</option></select></div><div className="search-input"><Search size={17}/><input aria-label="Buscar pedidos" placeholder="Buscar cliente o producto…" value={query} onChange={e=>setQuery(e.target.value)}/></div></div>{error&&<div className="error-box" role="alert">{error}<button className="text-button" onClick={()=>setRefresh(r=>r+1)}>Reintentar</button></div>}{loading?<OrderLoading/>:shown.length?<><div className="orders-table-wrap"><table className="orders-table"><thead><tr><th>PRODUCTO</th><th>CLIENTE</th><th>PRECIO / UD.</th><th>CANT.</th><th>TOTAL</th><th>ESTADO</th><th/></tr></thead><tbody>{shown.map(o=><tr key={o.id}><td><button className="product-cell" onClick={()=>setSelected(o)}><ProductImage order={o}/><span><strong>{o.product}</strong><small>#{o.id}</small></span></button></td><td><strong>{o.student}</strong><small>{o.section}</small></td><td>{usd(o.price)}</td><td>{o.quantity}</td><td><strong>{usd(o.price*o.quantity)}</strong></td><td><Status value={o.status}/></td><td><button className="icon-btn" aria-label={'Ver encargo de '+o.student} onClick={()=>setSelected(o)}><ArrowUpRight size={18}/></button></td></tr>)}</tbody></table></div><div className="mobile-orders">{shown.map(o=><button className="mobile-order" key={o.id} onClick={()=>setSelected(o)}><div className="mobile-order-main"><ProductImage order={o}/><span><strong>{o.product}</strong><small>{o.student} · {o.section}</small></span><ArrowUpRight size={16}/></div><div className="mobile-order-foot"><Status value={o.status}/><strong>{usd(o.price*o.quantity)}</strong></div></button>)}</div><div className="table-footer"><span>Mostrando {shown.length} de {orders.length} encargos</span><span>{demo?'Datos de ejemplo':'Actualización automática cada 30 segundos'}<span className="tiny-dot"/></span></div></>:<div className="empty"><span className="empty-icon"><ShoppingBag size={30}/></span><h3>{orders.length?'No hay coincidencias':'Tu próxima compra empieza aquí'}</h3><p>{orders.length?'Prueba con otro nombre o filtro.':'Los encargos aparecerán aquí cuando tus clientes los envíen desde la app.'}</p>{!orders.length&&<button className="secondary" onClick={copy}>Copiar enlace de la app <Copy size={16}/></button>}</div>}</section><div className="dashboard-tip"><ShieldCheck size={19}/><p><strong>Un recordatorio antes de comprar:</strong> confirma las tallas, colores y precios con cada cliente. Los importes son los que ellos enviaron.</p></div>{selected&&<Modal title="Detalle del encargo" wide busy={updating} onClose={()=>{if(!updating)setSelected(null);}}><div className="order-detail"><div className="detail-product"><ProductImage order={selected} large/><div><Status value={selected.status}/><h3>{selected.product}</h3><p>#{selected.id}</p></div></div><dl><div><dt>Cliente</dt><dd>{selected.student}</dd></div><div><dt>Referencia de entrega</dt><dd>{selected.section}</dd></div><div><dt>Precio por unidad</dt><dd>{usd(selected.price)}</dd></div><div><dt>Cantidad</dt><dd>{selected.quantity}</dd></div><div className="detail-total"><dt>Total estimado</dt><dd>{usd(selected.price*selected.quantity)}</dd></div><div><dt>Fecha de envío</dt><dd>{new Date(selected.created).toLocaleDateString('es-SV')}</dd></div></dl>{selected.note&&<div className="detail-note"><strong>Detalles del cliente</strong><p>{selected.note}</p></div>}<a className="secondary full" href={selected.link} target="_blank" rel="noopener noreferrer">Abrir producto en Temu <ExternalLink size={16}/></a><label htmlFor="order-status">Estado del encargo</label><select id="order-status" disabled={updating} value={selected.status} onChange={e=>updateStatus(e.target.value)}>{statuses.map(s=><option key={s}>{s}</option>)}</select>{updating&&<p className="small muted">Guardando cambio…</p>}<OrderLedger key={selected.id} order={selected} request={api} demo={demo} onBusyChange={setUpdating} onChange={()=>setRefresh(r=>r+1)}/>{demo&&<p className="small muted">Ejemplo ficticio. Los cambios no se guardan al salir.</p>}</div></Modal>}</>;
}
function ProductImage({order,large=false}){const Icon={audio:Headphones,bag:Backpack,shoes:Footprints,phone:Smartphone}[order.kind]||Package;return <span className={'product-image '+(order.kind||'')+(large?' large':'')}>{order.image?<img src={order.image} alt={order.product}/>:<Icon size={large?50:26}/>}</span>;}
function Status({value}){return <span className={'status status-'+statuses.indexOf(value)}><span/>{value}</span>;}
createRoot(document.getElementById('root')).render(<App/>);
