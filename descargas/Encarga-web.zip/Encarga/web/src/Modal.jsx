import React,{useEffect,useRef} from 'react';
import {X} from 'lucide-react';

export default function Modal({title,onClose,children,wide=false,busy=false,id}) {
  const ref=useRef();
  const close=useRef(onClose);
  const saving=useRef(busy);
  saving.current=busy;
  close.current=onClose;
  useEffect(()=>{
    const old=document.body.style.overflow;
    const previous=document.activeElement;
    document.body.style.overflow='hidden';
    ref.current?.focus();
    const onKey=event=>{
      if(event.key==='Escape'&&!saving.current)close.current();
      if(event.key!=='Tab')return;
      const focusable=[...ref.current.querySelectorAll('button, a[href], input, select, textarea, [tabindex="0"]')].filter(el=>!el.matches(':disabled')&&el.getClientRects().length);
      const first=focusable[0],last=focusable.at(-1);
      if(!first){event.preventDefault();return;}
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===ref.current||!ref.current.contains(document.activeElement))){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===ref.current||!ref.current.contains(document.activeElement))){event.preventDefault();first.focus();}
    };
    document.addEventListener('keydown',onKey);
    return()=>{document.body.style.overflow=old;document.removeEventListener('keydown',onKey);previous?.focus();};
  },[]);
  return <div className="modal-backdrop" onClick={event=>{if(event.target===event.currentTarget&&!busy)onClose();}}>
    <section id={id} ref={ref} tabIndex={-1} className={'modal'+(wide?' settings-modal':'')} role="dialog" aria-modal="true" aria-label={title}>
      <div className="modal-heading"><h2>{title}</h2><button type="button" className="icon-btn" aria-label="Cerrar ventana" disabled={busy} onClick={onClose}><X size={21}/></button></div>
      {children}
    </section>
  </div>;
}
