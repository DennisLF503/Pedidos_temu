# Encarga: instalación y operación de una tienda

Esta edición es **una instalación independiente por tienda**, con varios
administradores. No es una plataforma multiempresa ni incluye suscripciones,
cobro de tarjetas, facturación fiscal o una garantía de entrega de Temu.

## Antes de vender o publicar

- Hacer un piloto real de pedidos, abonos, cancelaciones y entregas con la tienda.
- Acordar marca, precio, soporte, horarios, política de devoluciones y quién es
  responsable de la información. No prometer funciones aún no incluidas.
- Publicar una política de privacidad adaptada al negocio: responsable y contacto,
  finalidad de nombres/notas/imágenes, proveedores, acceso de administradores,
  plazo de conservación y medio para solicitar corrección/eliminación. Este
  documento técnico no sustituye revisión jurídica ni es un contrato comercial.
- Configurar un dominio, HTTPS, respaldos externos, alertas de caída y capacidad
  de disco. Las imágenes se almacenan dentro de SQLite y aumentan su tamaño.
- Mantener una sola instancia/proceso de Encarga por base de datos. No compartir
  SQLite por NFS ni ejecutar dos despachadores de notificaciones simultáneos.
- Crear la cuenta inicial **antes de exponer el sitio a internet**: el registro
  inicial otorga control de la tienda al primero que lo completa.

## Instalación con Docker Compose

Requisitos del servidor: Docker/Compose y proxy HTTPS (ejemplo: Caddy). La imagen
usa Node 24, ejecuta como usuario `node` y conserva SQLite en un volumen persistente.
Docker no fue ejecutado en el entorno de desarrollo; validar esta receta en el
servidor antes del lanzamiento.

```sh
cp .env.example .env
chmod 600 .env
# En un servidor Linux: el usuario node del contenedor usa UID/GID 1000.
sudo install -d -m 700 -o 1000 -g 1000 backups
docker compose up -d --build
docker compose ps
curl --fail http://127.0.0.1:3000/api/health
```

El puerto queda accesible **solo desde el servidor**, no desde internet.
Completar el registro inicial mediante un túnel SSH seguro desde tu computadora:
`ssh -L 3000:127.0.0.1:3000 usuario@servidor`, y abrir `http://localhost:3000`.
No enviar contraseñas en parámetros de comandos ni en conversaciones.

Después configurar DNS, abrir 80/443 y activar un proxy HTTPS. `deploy/Caddyfile`
es un ejemplo para Caddy instalado en el host (no en otro contenedor). Establecer
`APP_DOMAIN` en el entorno del servicio Caddy. No hay certificados ni dominio
contratados por este proyecto. Verificar acceso e instalación desde Android/iPhone,
y que la cookie `encarga_session` tenga `Secure` bajo HTTPS.

Para actualizar: respaldo verificado primero, luego `docker compose up -d --build`.
No ejecutar `docker compose down -v`: **eliminaría los datos persistentes**.
No volver a una versión antigua sobre una base con migraciones nuevas sin probar.

## Respaldos consistentes y automatización

```sh
docker compose exec -T app node scripts/storage.mjs backup /app/data/beta.sqlite /app/backups/tienda-2026-11-02.sqlite
```

Usar nombres únicos por ejecución. El comando admite la aplicación encendida:
`VACUUM INTO` crea una instantánea consistente, incluidos pedidos, imágenes,
cuentas, pagos, preferencias e historial. Verifica integridad y claves foráneas,
usa permisos 0600 y **nunca sobrescribe un destino existente**. No copiar únicamente
el archivo principal con `cp` mientras SQLite está activo.

Programar en el cron del servidor (ajustar `/srv/encarga` a la instalación real):

```cron
0 3 * * * cd /srv/encarga && /usr/bin/docker compose exec -T app node scripts/storage.mjs backup /app/data/beta.sqlite /app/backups/tienda-$(date +\%Y\%m\%d-\%H\%M\%S).sqlite
```

Configurar alertas ante cualquier fallo del cron y una copia **cifrada fuera del
servidor** mediante el proveedor elegido. No se ha configurado ningún servicio
externo automáticamente. Propuesta de retención: 7 diarias y 4 semanales, tras
verificar restauración. No borrar copias automáticamente sin esa verificación.
La copia contiene datos personales, hashes y sesiones: tratarla como secreto.

## Restauración (con la app detenida)

1. Detener la app: `docker compose stop app`.
2. Restaurar en **un archivo nuevo**, preservando el original:

```sh
docker compose run --rm --no-deps app node scripts/storage.mjs restore /app/backups/tienda-2026-11-02.sqlite /app/data/restaurada.sqlite
```

3. Cambiar `DB_PATH` en `compose.yaml` a `/app/data/restaurada.sqlite` y recrear
   el servicio: `docker compose up -d app`.
4. Comprobar login, pedidos, imágenes, historial y saldos. Las sesiones anteriores
   quedan cerradas. Los avisos pendientes de la copia se cancelan para evitar
   volver a enviar mensajes ya enviados después del respaldo. No se reconstruyen
   automáticamente los movimientos posteriores a la fecha del respaldo.
5. Revisar/reconciliar pagos y mensajes con caja y los proveedores. No prometer
   recuperación de datos que nunca llegaron al respaldo.

Ensayar la restauración periódicamente en una instalación aislada y sin
credenciales de proveedores, para no enviar avisos de prueba a clientes reales.

## Acceso perdido

Cada administrador puede cambiar su contraseña en **Seguridad de mi acceso**;
se exige la actual y se cierran las demás sesiones. Si la olvida, la recuperación
la realiza el operador autorizado del servidor, previa verificación de identidad.
No se ha añadido recuperación pública por correo/SMS no verificado.

Con la aplicación detenida, desde una terminal privada del servidor (Bash):

```sh
read -r -p 'Teléfono del administrador: ' RECOVERY_PHONE
read -r -s -p 'Nueva contraseña: ' NEW_PASSWORD; echo
export RECOVERY_PHONE NEW_PASSWORD
docker compose run --rm --no-deps -e RECOVERY_PHONE -e NEW_PASSWORD app node scripts/reset-password.mjs
unset RECOVERY_PHONE NEW_PASSWORD
docker compose up -d app
```

El comando solo recupera un acceso existente y activo, nunca crea ni reactiva uno.
Revoca sus sesiones y registra la recuperación en el historial. Para ejecución
sin Docker: `DB_PATH=data/beta.sqlite npm run recover-access` con el mismo entorno.

## Dinero y controles operativos

En el detalle de cada encargo: registrar importe recibido, método y nota. Los
importes son centavos enteros en USD. No se acepta más del saldo ni un pago nuevo
en un pedido cancelado. Reintentar la misma solicitud no duplica su movimiento.
Para corregir: **Anular**, indicando motivo; se conserva el original y el historial.
Anular no transfiere dinero: el reembolso real se hace y verifica fuera de la app.

El saldo usa el precio estimado enviado por el cliente. Esta versión no añade
margen, envío, impuestos ni ajustes posteriores de precio. Si el negocio cobra
cargos adicionales, acordar ese proceso antes del piloto; no usar el saldo como
factura fiscal. El CSV incluye total, abonado, saldo y estado (cancelados incluidos).
El historial identifica los accesos mediante referencias internas (también visibles
en Administradores), sin nombres personales ni teléfonos. Muestra los últimos 100 eventos; los anteriores siguen en SQLite.
No se inventa historial retroactivo para pedidos anteriores a la actualización.

## Notificaciones, monitoreo y límites

Configurar Resend/Twilio con `.env.example`. Validar los canales y plantillas de
WhatsApp con el proveedor; un estado aceptado no prueba entrega. La app funciona
sin mensajes, pero no debe venderse como envío real configurado hasta probarlo.

Monitorear `/api/health` (no expone contactos), espacio de disco, fallos de respaldo,
logs y cola de avisos. El endpoint confirma que el proceso y SQLite responden,
no que los proveedores funcionen. Los registros de pagos no sustituyen conciliación
de caja. Los administradores tienen iguales permisos: asignarlos solo a personas
de confianza. Los eventos no son una auditoría certificada contra manipulación
por alguien con acceso al servidor. El limitador de solicitudes es local al proceso;
detrás de un proxy agrupa por la IP del proxy. Antes de alto tráfico, configurar
límites adecuados en el proxy sin confiar ciegamente en cabeceras enviadas por clientes.
