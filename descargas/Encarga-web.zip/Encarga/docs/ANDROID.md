# Mis pedidos · Android

Primera versión nativa para gestionar pedidos de Temu **para clientes**. Interfaz en español, Kotlin + Jetpack Compose, cuentas por correo y sincronización mediante Firebase. Proyecto independiente, sin afiliación con Temu.

## Funciones

- Registro, inicio/cierre de sesión y recuperación de contraseña.
- Alta y edición de clientes (nombre y teléfono).
- Alta, edición y eliminación confirmada de pedidos.
- Producto, cantidad, total a cobrar, abono acumulado, saldo, seguimiento y notas.
- Estados: por comprar, comprado, en camino, recibido y entregado.
- Resumen de saldo por cobrar y pedidos pendientes de entrega.
- Búsqueda por cliente/producto y filtros por estado o saldo pendiente.
- Datos separados por usuario, sincronizados en tiempo real al conectarse desde otros dispositivos.
- Importes en USD, almacenados como centavos enteros para evitar errores de coma flotante.

## Requisitos

- Android Studio con soporte para Android Gradle Plugin 8.9.1.
- JDK 17 y Android SDK 35 (instalables desde Android Studio).
- Dispositivo o emulador con Android 8.0 (API 26) o superior.
- Acceso a internet y un proyecto Firebase propio.

## Configurar Firebase

1. Crea un proyecto en la consola de Firebase.
2. Añade una aplicación Android con el identificador **`com.pedidostemu.app`**.
3. Descarga `google-services.json` y colócalo en `app/google-services.json`. Está excluido de Git; no hace falta compartirlo por chat. No uses una clave de cuenta de servicio.
4. En **Authentication → Sign-in method**, habilita **Correo electrónico/contraseña**. No es necesario habilitar acceso por enlace.
5. Crea una base de datos **Cloud Firestore**, en modo producción y en la región que prefieras. La app utiliza la base predeterminada `(default)`.
6. Copia el contenido de `firestore.rules` a la pestaña **Reglas** y publícalo. Alternativamente, con Firebase CLI instalado y autenticado: `firebase deploy --only firestore:rules --project TU_ID_DE_PROYECTO`.
7. Sincroniza Gradle y ejecuta la aplicación.

Sin `google-services.json`, la aplicación muestra instrucciones de configuración: **no simula una conexión ni guarda datos**. Tras añadir el archivo, vuelve a sincronizar y compilar.

Las colecciones son `users/{uid}/customers` y `users/{uid}/orders`. Las reglas impiden acceder a otras cuentas y validan tipos, límites, estados y referencias a clientes. Los clientes no se eliminan para no dejar pedidos sin referencia. No uses reglas públicas de prueba en producción.

## Compilar y probar

```sh
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

APK de desarrollo: `app/build/outputs/apk/debug/app-debug.apk`.
En Windows utiliza `gradlew.bat`. Para distribuir una versión release, configura una clave de firma propia desde **Build → Generate Signed App Bundle / APK**, fuera del repositorio.

El wrapper oficial de Gradle está incluido. La primera compilación descarga Gradle y dependencias; requiere acceso a los repositorios de Google y Maven Central.

## Comprobación manual recomendada

1. Crea una cuenta; añade un cliente y un pedido por $25.50 con $10 abonados. El saldo debe ser $15.50.
2. Edita el abono acumulado a $25.50: debe mostrarse pagado.
3. Cambia los estados y comprueba los filtros, búsqueda y contador de pendientes.
4. Abre la misma cuenta en otro dispositivo y comprueba la sincronización.
5. Cierra sesión y crea otra cuenta: no debe ver los datos de la anterior.
6. En el simulador de reglas de Firebase, verifica que un UID ajeno no puede leer/escribir; que abonos mayores al total, importes negativos y clientes de otra cuenta se rechazan.
7. Desconecta internet e intenta guardar: la app no debe informar de éxito hasta que Firestore confirme la escritura. Reconecta para completar la operación.
8. Comprueba recuperación de contraseña y eliminación con confirmación.

## Alcance y límites de esta versión

- Registro manual: no importa pedidos de Temu ni consulta transportistas. El estado y el seguimiento se actualizan manualmente.
- El abono es un **acumulado editable**, no un historial contable de movimientos. No hay inventario, exportación, notificaciones ni archivos adjuntos.
- No hay modo offline garantizado: la caché de Firestore se mantiene en memoria, no en disco, para no conservar datos de clientes tras cerrar sesión en dispositivos compartidos. Los cambios se consideran guardados solo cuando el servidor los confirma.
- Ediciones simultáneas del mismo pedido siguen la política de última escritura de Firestore.
- Cada cuenta tiene su propio negocio; todavía no hay roles ni colaboración entre cuentas.
- Antes de publicar: probar en dispositivos reales, validar reglas con Firebase Emulator Suite, configurar App Check, política de privacidad, eliminación de cuenta/datos y firma de producción. Controla las cuotas y costos de Firebase.

## Verificación en este entorno

Se incluyeron pruebas unitarias para conversión de importes, saldos y estados. Este entorno no dispone de JDK ni SDK Android, por lo que **no se ha compilado el APK ni ejecutado las pruebas Android/JUnit**. Deben ejecutarse con los comandos anteriores en Android Studio o un entorno de CI configurado.
